package EVRPYamin;

import java.util.ArrayList;

public class CRoute {
    public double total_energy;
    public double cost;              // distance + TW penalty (not depot penalty)
    public double searchCost;        // route-level search surrogate
    public double travel_distance;
    public double charging_time;
    public double last_depart_time;
    public double load;
    public ArrayList<Integer> path = new ArrayList<>();
    public boolean isempty = false;
    public float penalty_r;
    public float penalty_t;
    public ArrayList<Integer> firstArc = new ArrayList<>();
    public double penalty;
    public double lamada;

    /** Nondominated multigraph realizations for this fixed customer sequence. */
    public ArrayList<CRouteOption> options = new ArrayList<>();
    public int selectedOptionIndex = -1;

    public CRouteOption selectedOption() {
        if (selectedOptionIndex < 0 || selectedOptionIndex >= options.size()) return null;
        return options.get(selectedOptionIndex);
    }

    public void selectOption(int idx) {
        if (idx < 0 || idx >= options.size()) throw new IllegalArgumentException("Bad option index " + idx);
        selectedOptionIndex = idx;
        CRouteOption o = options.get(idx);
        total_energy = o.energy;
        travel_distance = o.distance;
        charging_time = o.chargingTime;
        last_depart_time = o.latestDeparture;
        penalty_t = (float)o.lateness;
        penalty_r = (float)o.energyViolationPercent();
        penalty = CData.penalty_init * o.lateness + CData.penaltyEnergy * o.energyViolationPercent();
        cost = o.distance + penalty;
        searchCost = cost + CData.lambda * o.chargingTime;
        firstArc = new ArrayList<>(o.arcTypes);
    }

    public CRoute copy() {
        CRoute r = new CRoute();
        r.copyFrom(this);
        return r;
    }

    public void copyFrom(CRoute other) {
        total_energy = other.total_energy; cost = other.cost; searchCost = other.searchCost;
        travel_distance = other.travel_distance; charging_time = other.charging_time;
        last_depart_time = other.last_depart_time; load = other.load;
        path = new ArrayList<>(other.path); isempty = other.isempty;
        penalty_r = other.penalty_r; penalty_t = other.penalty_t;
        firstArc = new ArrayList<>(other.firstArc); penalty = other.penalty; lamada = other.lamada;
        options = new ArrayList<>(); for (CRouteOption o : other.options) options.add(o.copy());
        selectedOptionIndex = other.selectedOptionIndex;
    }

    @Override public String toString() {
        return String.format(java.util.Locale.US,
                "path=%s dist=%.1f energy=%.2f eViol=%.2f%% charge=%.0f latest=%.1f late=%.1f option=%d/%d",
                path, travel_distance, total_energy, (double)penalty_r, charging_time, last_depart_time,
                (double)penalty_t, selectedOptionIndex, options.size());
    }
}
