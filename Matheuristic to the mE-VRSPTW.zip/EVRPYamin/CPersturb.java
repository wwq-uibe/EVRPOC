package EVRPYamin;

import java.util.*;

/** Diversified destroy-and-repair perturbation. */
public final class CPersturb {
    private CPersturb() {}
    public static Random ran=new Random();

    public static void Run(double ratio) {
        // Route-removal is particularly useful when the current solution has one
        // unnecessary route. It is attempted as a diversification move, so it need
        // not immediately improve the search score.
        if(ran.nextDouble()<0.06 && CRouteElimination.PerturbRandom(ran,1)) return;

        int n=CData.customerCount();
        int removeN=Math.max(1,(int)Math.ceil(n*Math.max(0.02,Math.min(0.5,ratio))));
        ArrayList<Integer> removed;
        double u=ran.nextDouble();
        if(u<0.34) removed=randomRemoval(removeN);
        else if(u<0.67) removed=shawRemoval(removeN);
        else removed=worstRemoval(removeN);

        HashSet<Integer> rm=new HashSet<>(removed);
        ArrayList<CRoute> kept=new ArrayList<>();
        for(CRoute old:CSolution.Route){
            ArrayList<Integer> p=new ArrayList<>();p.add(0);
            for(int k=1;k<old.path.size()-1;k++)if(!rm.contains(old.path.get(k)))p.add(old.path.get(k));
            p.add(0);
            if(CSolution.customerCount(p)==0)continue;
            CRoute r=new CRoute();CEvaluationRoute.Run(p,r);
            if(!Double.isFinite(r.cost)) throw new IllegalStateException("Perturbation created hard-infeasible residual route");
            kept.add(r);
        }

        // Regret-2 repair is substantially more robust than a random sequential
        // greedy insertion, especially after related/worst removals.
        ArrayList<CRoute> repaired=CRouteElimination.RepairByRegret(kept,removed,true);
        if(repaired==null){
            // Very defensive fallback: start from the residual routes and use the
            // old sequential insertion so customer coverage is preserved.
            CSolution.Route=CSolution.CopyRouteList(kept);
            CSolution.UpdateInformation();
            Collections.shuffle(removed,ran);
            for(int c:removed) insertCustomer(c);
        }else{
            CSolution.Route=repaired;
            CSolution.UpdateInformation();
        }
    }

    private static ArrayList<Integer> randomRemoval(int removeN){
        ArrayList<Integer> all=new ArrayList<>();for(int c=1;c<=CData.customerCount();c++)all.add(c);
        Collections.shuffle(all,ran);
        return new ArrayList<>(all.subList(0,Math.min(removeN,all.size())));
    }

    /** Related-customer (Shaw-style) removal. */
    private static ArrayList<Integer> shawRemoval(int removeN){
        int n=CData.customerCount();
        ArrayList<Integer> removed=new ArrayList<>();
        HashSet<Integer> used=new HashSet<>();
        int seed=1+ran.nextInt(n);removed.add(seed);used.add(seed);
        while(removed.size()<Math.min(removeN,n)){
            int pivot=removed.get(ran.nextInt(removed.size()));
            ArrayList<Integer> cand=new ArrayList<>();
            for(int c=1;c<=n;c++)if(!used.contains(c))cand.add(c);
            cand.sort(Comparator.comparingDouble(c->relatedness(pivot,c)));
            int pool=Math.min(cand.size(),Math.max(1,(int)Math.ceil(Math.sqrt(cand.size()))));
            int chosen=cand.get(ran.nextInt(pool));
            removed.add(chosen);used.add(chosen);
        }
        return removed;
    }

    /** Remove customers with the largest cheap geometric removal saving. */
    private static ArrayList<Integer> worstRemoval(int removeN){
        ArrayList<Integer> all=new ArrayList<>();for(int c=1;c<=CData.customerCount();c++)all.add(c);
        all.sort((a,b)->Double.compare(removalSaving(b),removalSaving(a)));
        ArrayList<Integer> out=new ArrayList<>();
        while(out.size()<Math.min(removeN,all.size())){
            int pool=Math.min(all.size(),Math.max(1,2*(removeN-out.size())));
            int idx=ran.nextInt(pool);
            out.add(all.remove(idx));
        }
        return out;
    }

    private static double removalSaving(int c){
        int r=CData.nodes.get(c).GetRow(), p=CData.nodes.get(c).GetCol();
        if(r<0||p<1)return 0;
        ArrayList<Integer> path=CSolution.Route.get(r).path;
        int a=path.get(p-1),b=path.get(p+1);
        return minDist(a,c)+minDist(c,b)-minDist(a,b);
    }
    private static double minDist(int i,int j){return Math.min(CData.euclideanDistance[i][j],CData.manhattanDistance[i][j]);}
    private static double relatedness(int i,int j){
        double d=minDist(i,j);CNode a=CData.nodes.get(i),b=CData.nodes.get(j);
        double tw=Math.max(0,b.early_time-a.due_time-a.service_time-d)
                +Math.max(0,a.early_time+a.service_time+d-b.due_time);
        return d+0.2*tw;
    }

    private static void insertCustomer(int c) {
        double best=Double.POSITIVE_INFINITY;int bestRow=-2;CRoute bestRoute=null;
        for(int r=0;r<CSolution.Route.size();r++){
            CRoute old=CSolution.Route.get(r);
            for(int pos=1;pos<old.path.size();pos++){
                ArrayList<Integer> p=new ArrayList<>(old.path);p.add(pos,c);CRoute nr=new CRoute();CEvaluationRoute.Run(p,nr);
                if(!Double.isFinite(nr.cost))continue;
                ArrayList<CRoute> temp=new ArrayList<>(CSolution.Route);temp.set(r,nr);double s=CSolution.ComputeSearchScore(temp);
                if(s<best){best=s;bestRow=r;bestRoute=nr;}
            }
        }
        ArrayList<Integer> single=new ArrayList<>(Arrays.asList(0,c,0));CRoute sr=new CRoute();CEvaluationRoute.Run(single,sr);
        if(Double.isFinite(sr.cost)){
            ArrayList<CRoute> temp=new ArrayList<>(CSolution.Route);temp.add(sr);double s=CSolution.ComputeSearchScore(temp);
            if(s<best||bestRoute==null){best=s;bestRow=-1;bestRoute=sr;}
        }
        if(bestRoute==null)throw new IllegalStateException("Cannot reinsert customer "+c);
        if(bestRow==-1)CSolution.Route.add(bestRoute);else CSolution.Route.set(bestRow,bestRoute);
        CSolution.UpdateInformation();
    }
}
