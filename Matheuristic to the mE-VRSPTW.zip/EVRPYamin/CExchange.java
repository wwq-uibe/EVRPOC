package EVRPYamin;
import java.util.*;
/** 2-opt* tail exchange between two routes. */
public final class CExchange {
    private CExchange() {}
    public static double Calculate(int cus1,int cus2,CRoute cr1,CRoute cr2){
        int r1=CData.nodes.get(cus1).GetRow(),r2=CData.nodes.get(cus2).GetRow(); int c1=CData.nodes.get(cus1).GetCol(),c2=CData.nodes.get(cus2).GetCol();
        if(r1<0||r2<0||r1==r2)return Double.POSITIVE_INFINITY;
        ArrayList<Integer>a=CSolution.Route.get(r1).path,b=CSolution.Route.get(r2).path,p1=new ArrayList<>(),p2=new ArrayList<>();
        for(int i=0;i<c1;i++)p1.add(a.get(i)); for(int i=c2;i<b.size();i++)p1.add(b.get(i));
        for(int i=0;i<c2;i++)p2.add(b.get(i)); for(int i=c1;i<a.size();i++)p2.add(a.get(i));
        if(CSolution.customerCount(p1)==0||CSolution.customerCount(p2)==0)return Double.POSITIVE_INFINITY;
        CEvaluationRoute.Run(p1,cr1);CEvaluationRoute.Run(p2,cr2);if(!Double.isFinite(cr1.cost)||!Double.isFinite(cr2.cost))return Double.POSITIVE_INFINITY;
        return CSolution.ScoreAfterReplacement(r1,cr1,r2,cr2);
    }
    public static void UpdateCurSolution(int cus1,int cus2,CRoute cr1,CRoute cr2){int r1=CData.nodes.get(cus1).GetRow(),r2=CData.nodes.get(cus2).GetRow();CSolution.Route.set(r1,cr1);CSolution.Route.set(r2,cr2);CSolution.UpdateInformation();}
}
