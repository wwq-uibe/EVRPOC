package EVRPYamin;

import java.util.*;

/** Adaptive iterated local search for the Yamín multigraph EV routing + overnight charging problem. */
public final class CAILS {
    private CAILS() {}

    public static void Run(int iterations,double neighborRatio,double pairSampleRatio,double perturbRatio) {
        // Fresh random streams on every execution: no fixed/reproducible seed.
        Random ran=new Random();
        CLingyu.ran=new Random();
        CLocalSearch1.ran=new Random();
        CPersturb.ran=new Random();

        CPoolRoute.Initialize(1500);
        CInitS.Run(ran);CLingyu.Init(neighborRatio);
        CSaveSolution.Init(1000,0.05,1.5,20);CSaveSolution.Run();

        // V3.3 strategic oscillation keeps infeasible excursions short.  The search
        // may cross the E boundary for a few iterations, then CEnergyRepair projects
        // it back to the physical region before the excursion can become a new basin.
        final int MAX_RELAXED_STREAK=5;
        int relaxedStreak=0;
        ArrayList<CRoute> lastEnergyFeasible=CSolution.CopyRouteList(CSolution.Route);

        long t0=System.currentTimeMillis();
        for(int it=1;it<=iterations;it++){
            ArrayList<CRoute> base=CSolution.CopyRouteList(CSolution.Route);
            double baseScore=CSolution.searchCost;

            CPersturb.Run(perturbRatio);
            // Cheap VND every iteration; strong neighborhoods periodically.
            boolean strongIteration=(it<=20 || it%10==0);
            for(int pass=0;pass<5;pass++){
                boolean strong=strongIteration && pass==0;
                if(!CLocalSearch1.Run(pairSampleRatio,0.08,strong))break;
            }

            // Controlled energy relaxation: allow a short infeasible corridor, but
            // periodically force a constructive return to energy <= E.
            if(CSolution.energyViolation>1e-8){
                relaxedStreak++;
                if(relaxedStreak>=MAX_RELAXED_STREAK){
                    boolean repaired=CEnergyRepair.Run();
                    if(!repaired && lastEnergyFeasible!=null && !lastEnergyFeasible.isEmpty()){
                        CSolution.Route=CSolution.ReevaluatedCopy(lastEnergyFeasible);
                        CSolution.UpdateInformation();
                    }
                    relaxedStreak=0;
                }
            }else{
                relaxedStreak=0;
                lastEnergyFeasible=CSolution.CopyRouteList(CSolution.Route);
            }

            // Store good routes/incumbents and update adaptive TW/energy/depot penalties.
            boolean penaltyChanged=CSaveSolution.Run();
            if(CSolution.energyViolation<=1e-8)
                lastEnergyFeasible=CSolution.CopyRouteList(CSolution.Route);

            // Compare base and candidate under the same penalty values.
            ArrayList<CRoute> comparableBase=base;
            double comparableBaseScore=baseScore;
            if(penaltyChanged){
                comparableBase=CSolution.ReevaluatedCopy(base);
                comparableBaseScore=CSolution.ComputeSearchScore(comparableBase);
            }

            double temp=Math.max(0.25,5.0*(1.0-(double)it/Math.max(1,iterations)));
            double delta=CSolution.searchCost-comparableBaseScore;
            if(delta>0 && ran.nextDouble()>Math.exp(-Math.min(100,delta)/temp)){
                CSolution.Route=CSolution.CopyRouteList(comparableBase);CSolution.UpdateInformation();
            }

            if(it%250==0){
                // V3.4 route-option SP.  Depot charging is enforced inside the MIP
                // through proof-safe lazy feasibility cuts; no charging-start variables
                // are enumerated.  Keep the call deliberately infrequent.
                CSetPartitioning.Result sp=CSetPartitioning.Run(0.9);
                if(sp!=null && sp.improved && !CSaveSolution.Best_Route_Depot_Feasible.isEmpty()){
                    CSolution.Route=CSolution.CopyRouteList(CSaveSolution.Best_Route_Depot_Feasible);
                    CSolution.RestoreDepotSchedule(CSaveSolution.Best_Depot_Schedule);
                }

                if(!CSaveSolution.Best_Route_Depot_Feasible.isEmpty()){
                    // Preserve the fixed restart schedule around the best validated incumbent.
                    CSolution.Route=CSolution.CopyRouteList(CSaveSolution.Best_Route_Depot_Feasible);
                    CSolution.RestoreDepotSchedule(CSaveSolution.Best_Depot_Schedule);
                }
            }
            if(it%100==0 || it==iterations){
                double sec=(System.currentTimeMillis()-t0)/1000.0;
                System.out.printf(Locale.US,
                        "iter=%d cur=%.1f search=%.2f best=%.1f routes=%d eV=%.2f%% lambda=%.2f pTW=%.2f pE=%.2f pDepot=%.2f pool=%d time=%.1fs%n",
                        it,CSolution.cost,CSolution.searchCost,CSaveSolution.best_route_depot_feasible_cost,
                        CSolution.Route.size(),CSolution.energyViolation,CData.lambda,CData.penalty_init,
                        CData.penaltyEnergy,CData.penaltyDepot,CPoolRoute.Size(),sec);
            }
        }

        // One slightly longer lazy-charging SP pass before final reporting.
        CSetPartitioning.Result finalSP=CSetPartitioning.Run(3.0);
        if(finalSP!=null && finalSP.improved)
            System.out.printf(Locale.US,"[SP] final improvement -> %.1f%n",CSaveSolution.best_route_depot_feasible_cost);

        if(!CSaveSolution.Best_Route_Depot_Feasible.isEmpty()){
            CSolution.Route=CSolution.CopyRouteList(CSaveSolution.Best_Route_Depot_Feasible);
            CSolution.RestoreDepotSchedule(CSaveSolution.Best_Depot_Schedule);
        }else if(!CSaveSolution.Best_Route_Feasible.isEmpty()){
            // Diagnostic fallback only when no depot-feasible incumbent was found.
            CSolution.Route=CSolution.CopyRouteList(CSaveSolution.Best_Route_Feasible);
            CSolution.OptimizeDepotOptions();
        }
    }
}
