package EVRPYamin;
import java.util.*;
public final class CSwap {
    private CSwap() {}
    public static double Calculate(int cus1,int cus2,CRoute cr1,CRoute cr2){
        if(cus1==cus2)return Double.POSITIVE_INFINITY;
        int r1=CData.nodes.get(cus1).GetRow(),r2=CData.nodes.get(cus2).GetRow(); int c1=CData.nodes.get(cus1).GetCol(),c2=CData.nodes.get(cus2).GetCol();
        if(r1<0||r2<0)return Double.POSITIVE_INFINITY;
        if(r1==r2){ ArrayList<Integer> p=new ArrayList<>(CSolution.Route.get(r1).path); p.set(c1,cus2);p.set(c2,cus1); CEvaluationRoute.Run(p,cr1); if(!Double.isFinite(cr1.cost))return Double.POSITIVE_INFINITY; return CSolution.ScoreAfterReplacement(r1,cr1,-1,null); }
        ArrayList<Integer> p1=new ArrayList<>(CSolution.Route.get(r1).path),p2=new ArrayList<>(CSolution.Route.get(r2).path); p1.set(c1,cus2);p2.set(c2,cus1);
        CEvaluationRoute.Run(p1,cr1);CEvaluationRoute.Run(p2,cr2); if(!Double.isFinite(cr1.cost)||!Double.isFinite(cr2.cost))return Double.POSITIVE_INFINITY;
        return CSolution.ScoreAfterReplacement(r1,cr1,r2,cr2);
    }
    public static void UpdateCurSolution(int cus1,int cus2,CRoute cr1,CRoute cr2){int r1=CData.nodes.get(cus1).GetRow(),r2=CData.nodes.get(cus2).GetRow();CSolution.Route.set(r1,cr1);if(r2!=r1)CSolution.Route.set(r2,cr2);CSolution.UpdateInformation();}
}
