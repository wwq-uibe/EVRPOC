package EVRPYamin;

import java.util.*;

/**
 * Or-opt neighborhood: relocate an ordered chain of 2 or 3 customers before/after
 * a related anchor customer. Reversed-chain variants are also tested.
 */
public final class COrOpt {
    private COrOpt() {}
    private static final double EPS = 1e-9;

    public static boolean Run(ArrayList<ArrayList<Integer>> candidates) {
        double incumbent = CSolution.searchCost;
        Collections.shuffle(candidates, CLocalSearch1.ran);
        for (ArrayList<Integer> pair : candidates) {
            if (pair == null || pair.size() < 2) continue;
            int anchor = pair.get(0), first = pair.get(1);
            if (anchor == first) continue;

            int sourceRow = CData.nodes.get(first).GetRow();
            int targetRow = CData.nodes.get(anchor).GetRow();
            int start = CData.nodes.get(first).GetCol();
            if (sourceRow < 0 || targetRow < 0 || start < 1) continue;

            CRoute source = CSolution.Route.get(sourceRow);
            int lastCustomerPos = source.path.size() - 2;
            for (int len = 2; len <= 3; len++) {
                if (start + len - 1 > lastCustomerPos) continue;
                // Cheap load pre-screen for inter-route moves.
                if(sourceRow!=targetRow){
                    double q=0;for(int z=start;z<start+len;z++)q+=CData.nodes.get(source.path.get(z)).demand;
                    if(CSolution.Route.get(targetRow).load+q>CData.Q+1e-9)continue;
                }
                for (boolean after : new boolean[]{false, true}) {
                    for (boolean reverse : new boolean[]{false, true}) {
                        ArrayList<CRoute> candidate = buildMove(sourceRow, targetRow, start, len, anchor, after, reverse);
                        if (candidate == null) continue;
                        double score = CSolution.ComputeSearchScore(candidate);
                        if (score < incumbent - EPS) {
                            CSolution.Route = candidate;
                            CSolution.UpdateInformation();
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private static ArrayList<CRoute> buildMove(int sourceRow, int targetRow, int start, int len,
                                                int anchor, boolean after, boolean reverse) {
        ArrayList<CRoute> temp = CSolution.CopyRouteList(CSolution.Route);
        CRoute srcOld = temp.get(sourceRow);
        if (start < 1 || start + len > srcOld.path.size() - 1) return null;

        ArrayList<Integer> segment = new ArrayList<>(srcOld.path.subList(start, start + len));
        if (segment.contains(anchor)) return null;
        if (reverse) Collections.reverse(segment);

        if (sourceRow == targetRow) {
            ArrayList<Integer> p = new ArrayList<>(srcOld.path);
            p.subList(start, start + len).clear();
            int anchorPos = p.indexOf(anchor);
            if (anchorPos < 1) return null;
            int insertPos = after ? anchorPos + 1 : anchorPos;
            p.addAll(insertPos, segment);
            if (p.equals(srcOld.path)) return null;

            CRoute nr = new CRoute();
            CEvaluationRoute.Run(p, nr);
            if (!Double.isFinite(nr.cost)) return null;
            temp.set(sourceRow, nr);
            return temp;
        }

        CRoute tgtOld = temp.get(targetRow);
        ArrayList<Integer> srcPath = new ArrayList<>(srcOld.path);
        ArrayList<Integer> tgtPath = new ArrayList<>(tgtOld.path);
        srcPath.subList(start, start + len).clear();
        int anchorPos = tgtPath.indexOf(anchor);
        if (anchorPos < 1) return null;
        tgtPath.addAll(after ? anchorPos + 1 : anchorPos, segment);

        CRoute srcNew = new CRoute(), tgtNew = new CRoute();
        CEvaluationRoute.Run(srcPath, srcNew);
        CEvaluationRoute.Run(tgtPath, tgtNew);
        if (!Double.isFinite(srcNew.cost) || !Double.isFinite(tgtNew.cost)) return null;
        if (CSolution.customerCount(srcPath) == 0) srcNew.isempty = true;
        temp.set(sourceRow, srcNew);
        temp.set(targetRow, tgtNew);
        temp.removeIf(r -> r == null || r.isempty || CSolution.customerCount(r.path) == 0);
        return temp;
    }
}
