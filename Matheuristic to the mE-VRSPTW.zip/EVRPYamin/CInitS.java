package EVRPYamin;

import java.util.*;

/** Randomized greedy insertion initial solution using the multigraph route evaluator. */
public final class CInitS {
    private CInitS() {}

    public static void Run() { Run(new Random()); }

    public static void Run(Random ran) {
        CSolution.Init();
        ArrayList<Integer> unserved=new ArrayList<>();
        for(int c=1;c<=CData.customerCount();c++) unserved.add(c);

        while(!unserved.isEmpty()) {
            int seed=unserved.remove(ran.nextInt(unserved.size()));
            ArrayList<Integer> p=new ArrayList<>(); p.add(0);p.add(seed);p.add(0);
            CRoute route=new CRoute(); CEvaluationRoute.Run(p,route);
            if(!Double.isFinite(route.cost) || !CEvaluationRoute.selectBestTimeFeasible(route))
                throw new IllegalStateException("Singleton customer is not route-feasible: "+seed);

            while(!unserved.isEmpty()) {
                ArrayList<Insertion> cand=new ArrayList<>();
                for(int c:unserved) {
                    for(int pos=1;pos<route.path.size();pos++) {
                        ArrayList<Integer> q=new ArrayList<>(route.path); q.add(pos,c);
                        CRoute nr=new CRoute(); CEvaluationRoute.Run(q,nr);
                        if(!Double.isFinite(nr.cost) || !CEvaluationRoute.selectBestTimeFeasible(nr)) continue;
                        cand.add(new Insertion(c,nr,nr.travel_distance-route.travel_distance));
                    }
                }
                if(cand.isEmpty()) break;
                cand.sort(Comparator.comparingDouble(a->a.delta));
                int rcl=Math.min(3,cand.size());
                Insertion pick=cand.get(ran.nextInt(rcl));
                route=pick.route; unserved.remove(Integer.valueOf(pick.customer));
            }
            CSolution.Route.add(route);
        }
        CSolution.UpdateInformation();
        CSolution.OptimizeDepotOptions();
    }

    private static final class Insertion {
        int customer; CRoute route; double delta;
        Insertion(int c,CRoute r,double d){customer=c;route=r;delta=d;}
    }
}
