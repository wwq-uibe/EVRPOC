package EVRPYamin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Pareto preprocessing for the two multigraph alternatives. */
public final class CDominance {
    private CDominance() {}
    private static final double EPS = 1e-9;
    public static boolean[][] keepEuclidean;
    public static boolean[][] keepManhattan;
    private static List<Arc>[][] arcs;

    public enum Type { EUCLIDEAN, MANHATTAN }

    public static final class Arc {
        public final Type type;
        public final double distance;
        public final double time;
        public final double energy;
        private Arc(Type type, double distance, double time, double energy) {
            this.type = type; this.distance = distance; this.time = time; this.energy = energy;
        }
        @Override public String toString() {
            return type + "(d=" + distance + ", t=" + time + ", e=" + energy + ")";
        }
    }

    @SuppressWarnings("unchecked")
    public static void preprocess() {
        if (CData.euclideanDistance == null) throw new IllegalStateException("Call CData.read first");
        int n = CData.euclideanDistance.length;
        keepEuclidean = new boolean[n][n];
        keepManhattan = new boolean[n][n];
        arcs = (List<Arc>[][]) new List[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) {
            if (i == j) { arcs[i][j] = Collections.emptyList(); continue; }
            Arc e = new Arc(Type.EUCLIDEAN, CData.euclideanDistance[i][j], CData.euclideanTime[i][j], CData.euclideanEnergy[i][j]);
            Arc m = new Arc(Type.MANHATTAN, CData.manhattanDistance[i][j], CData.manhattanTime[i][j], CData.manhattanEnergy[i][j]);
            boolean eDom = dominates(e, m), mDom = dominates(m, e);
            boolean same = same(e.distance,m.distance) && same(e.time,m.time) && same(e.energy,m.energy);
            keepEuclidean[i][j] = !mDom;
            keepManhattan[i][j] = !eDom && !same;
            ArrayList<Arc> list = new ArrayList<>(2);
            if (keepEuclidean[i][j]) list.add(e);
            if (keepManhattan[i][j]) list.add(m);
            arcs[i][j] = Collections.unmodifiableList(list);
        }
    }

    private static boolean dominates(Arc a, Arc b) {
        boolean noWorse = a.distance <= b.distance + EPS && a.time <= b.time + EPS && a.energy <= b.energy + EPS;
        boolean strict = a.distance < b.distance - EPS || a.time < b.time - EPS || a.energy < b.energy - EPS;
        return noWorse && strict;
    }
    private static boolean same(double a, double b) { return Math.abs(a-b) <= EPS; }

    public static List<Arc> getArcs(int i, int j) {
        if (arcs == null) throw new IllegalStateException("Call CDominance.preprocess first");
        return arcs[i][j];
    }

    public static void printSummary() {
        int e = 0, m = 0, both = 0;
        for (int i=0;i<arcs.length;i++) for (int j=0;j<arcs.length;j++) if (i!=j) {
            if (keepEuclidean[i][j] && keepManhattan[i][j]) both++;
            else if (keepEuclidean[i][j]) e++;
            else if (keepManhattan[i][j]) m++;
        }
        System.out.println("Dominance preprocessing: Euclidean only="+e+", Manhattan only="+m+", both="+both);
    }
}
