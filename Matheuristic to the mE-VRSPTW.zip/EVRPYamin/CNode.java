package EVRPYamin;

public class CNode {
	public int demand;
	public int x;
	public int y;
	public double early_time;
	public double due_time;
	public double service_time;
	public int index;
	
	public int row=-1;
	public int col=-1;
	
	public double D;
	
	public void SetRow(int i) {
		row=i;
	}
	
	public int GetCol() {
		return col;
	}
	
	public int GetRow() {
		return row;
	}
	
	public void SetCol(int i) {
		col=i;
	}
	
	public double GetD() {
		return D;
	}
}
