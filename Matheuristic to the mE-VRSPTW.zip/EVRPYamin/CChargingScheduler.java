package EVRPYamin;

import java.util.*;

/** Depot charging scheduler and route-option coordinator. */
public final class CChargingScheduler {
    private CChargingScheduler() {}
    private static final double EPS = 1e-9;
    private static final long EXACT_OPTION_COMBINATION_LIMIT = 20000L;

    /*
     * IMPORTANT: fixed-option charging feasibility can be exponential.  The exact
     * public checker below is still unlimited (and therefore preserves correctness
     * when an exact answer is explicitly requested), while heuristic calls use a
     * deterministic DFS-node budget so a single candidate cannot stall AILS for
     * minutes.  A budgeted check is allowed to return "unknown/infeasible surrogate",
     * but it NEVER declares a solution feasible unless it has constructed a valid
     * charging schedule.
     */
    private static final long HEURISTIC_REPAIR_DFS_LIMIT = 12000L;
    private static final long HEURISTIC_SEED_DFS_LIMIT = 25000L;
    private static final long HEURISTIC_FINAL_DFS_LIMIT = 50000L;
    private static final int HEURISTIC_REPAIR_PASSES = 30;

    public static final class ScheduleResult {
        public boolean feasible;
        public double maxViolation;
        public double totalViolation;
        public double distance;
        public int[] optionIndex;
        public int[] charger;
        public double[] start;
        public double[] finish;

        /** True if a budgeted exact DFS was stopped before exhausting its search tree. */
        public boolean budgetExceeded;
        /** Number of DFS states visited by the fixed-option exact/budgeted checker. */
        public long dfsNodes;
        /** Number of route-option vectors examined by the V3.2 best-first coordinator. */
        public long optionStates;
        /** Total fixed-option DFS nodes spent inside the V3.2 coordinator. */
        public long optionDfsNodes;

        ScheduleResult(int n) {
            optionIndex = new int[n]; Arrays.fill(optionIndex,-1);
            charger = new int[n]; Arrays.fill(charger,-1);
            start = new double[n]; finish = new double[n];
        }

        /** Deep copy used to persist a validated incumbent charging schedule. */
        public ScheduleResult copy() {
            ScheduleResult c = new ScheduleResult(optionIndex.length);
            c.feasible = feasible;
            c.maxViolation = maxViolation;
            c.totalViolation = totalViolation;
            c.distance = distance;
            c.optionIndex = optionIndex.clone();
            c.charger = charger.clone();
            c.start = start.clone();
            c.finish = finish.clone();
            c.budgetExceeded = budgetExceeded;
            c.dfsNodes = dfsNodes;
            c.optionStates = optionStates;
            c.optionDfsNodes = optionDfsNodes;
            return c;
        }
    }

    private static final class Job {
        int route;
        double duration, deadline;
        Job(int route, double duration, double deadline) {
            this.route=route; this.duration=duration; this.deadline=deadline;
        }
    }


    /**
     * Search-only depot-load surrogate for V3.3 energy-relaxed routes.  Energy above E
     * is NOT considered physically feasible; its chargingTime was capped at the full
     * battery time by CEvaluationRoute.  This routine exists only so relaxed routing
     * states still feel depot congestion pressure instead of bypassing pDepot.
     */
    public static ScheduleResult searchSurrogateSchedule(List<CRoute> routes) {
        int n=routes.size();
        ScheduleResult res=new ScheduleResult(n);
        ArrayList<Job> jobs=new ArrayList<>();
        res.distance=0;
        for(int r=0;r<n;r++){
            CRoute route=routes.get(r);
            int oi=route.selectedOptionIndex;
            if(oi<0 || oi>=route.options.size()){res.maxViolation=Double.POSITIVE_INFINITY;return res;}
            CRouteOption o=route.options.get(oi);
            res.optionIndex[r]=oi; res.distance+=o.distance;
            jobs.add(new Job(r,o.chargingTime,Math.min(o.latestDeparture,CData.lastChargingPeriod+1.0)));
        }
        jobs.sort(Comparator.comparingDouble((Job j)->j.deadline).thenComparingDouble(j->-j.duration));
        double[] avail=new double[Math.max(1,CData.B)];Arrays.fill(avail,CData.firstChargingPeriod);
        for(Job j:jobs){
            int b=0;for(int k=1;k<avail.length;k++)if(avail[k]<avail[b]-EPS)b=k;
            double st=avail[b],fin=st+j.duration,v=Math.max(0.0,fin-j.deadline);
            res.maxViolation=Math.max(res.maxViolation,v);res.totalViolation+=v;
            res.charger[j.route]=b;res.start[j.route]=st;res.finish[j.route]=fin;avail[b]=fin;
        }
        res.feasible=false; // never a physical feasibility certificate
        return res;
    }

    /** Very fast EDF/list-scheduling surrogate for the options currently selected in each route. */
    public static ScheduleResult evaluateCurrent(List<CRoute> routes) {
        int[] idx = new int[routes.size()];
        for (int r=0;r<routes.size();r++) idx[r]=routes.get(r).selectedOptionIndex;
        return greedySchedule(routes,idx);
    }

    public static ScheduleResult greedySchedule(List<CRoute> routes, int[] optionIdx) {
        int n=routes.size();
        ScheduleResult res=new ScheduleResult(n);
        if (optionIdx.length!=n) throw new IllegalArgumentException("optionIdx length mismatch");
        ArrayList<Job> jobs=new ArrayList<>();
        res.distance=0;
        for (int r=0;r<n;r++) {
            CRoute route=routes.get(r);
            int oi=optionIdx[r];
            if (oi<0 || oi>=route.options.size()) { res.feasible=false; res.maxViolation=Double.POSITIVE_INFINITY; return res; }
            CRouteOption o=route.options.get(oi);
            if(!o.isPhysicalFeasible()) { res.feasible=false; res.maxViolation=Double.POSITIVE_INFINITY; return res; }
            res.optionIndex[r]=oi; res.distance+=o.distance;
            jobs.add(new Job(r,o.chargingTime,Math.min(o.latestDeparture,CData.lastChargingPeriod+1.0)));
        }
        jobs.sort(Comparator.comparingDouble((Job j)->j.deadline).thenComparingDouble(j->-j.duration));
        double[] avail=new double[Math.max(1,CData.B)]; Arrays.fill(avail,CData.firstChargingPeriod);
        for (Job j:jobs) {
            int b=0; for (int k=1;k<avail.length;k++) if (avail[k]<avail[b]-EPS) b=k;
            double s=avail[b], f=s+j.duration;
            double v=Math.max(0.0,f-j.deadline);
            res.maxViolation=Math.max(res.maxViolation,v); res.totalViolation+=v;
            res.charger[j.route]=b; res.start[j.route]=s; res.finish[j.route]=f;
            avail[b]=f;
        }
        res.feasible=res.maxViolation<=EPS;
        return res;
    }

    /**
     * Exact feasibility/schedule for a FIXED route-option vector (common release
     * time, identical chargers).  This call is deliberately UNBOUNDED: use
     * scheduleFixedOptionsWithBudget() inside heuristic search.
     */
    public static ScheduleResult exactScheduleFixedOptions(List<CRoute> routes, int[] optionIdx) {
        return scheduleFixedOptions(routes,optionIdx,0L);
    }

    /**
     * Budgeted fixed-option check used by the heuristic.  If the DFS budget is
     * exhausted, feasible=false is only a search surrogate; budgetExceeded=true
     * makes this explicit.  A feasible=true result is always backed by a concrete
     * valid charger assignment.
     */
    public static ScheduleResult scheduleFixedOptionsWithBudget(List<CRoute> routes, int[] optionIdx, long nodeLimit) {
        return scheduleFixedOptions(routes,optionIdx,Math.max(1L,nodeLimit));
    }

    private static ScheduleResult scheduleFixedOptions(List<CRoute> routes, int[] optionIdx, long nodeLimit) {
        int n=routes.size();
        ScheduleResult base=new ScheduleResult(n);
        ArrayList<Job> jobs=new ArrayList<>();
        for (int r=0;r<n;r++) {
            CRoute route=routes.get(r); int oi=optionIdx[r];
            if (oi<0 || oi>=route.options.size()) { base.maxViolation=Double.POSITIVE_INFINITY; return base; }
            CRouteOption o=route.options.get(oi);
            if (!o.isPhysicalFeasible()) { base.maxViolation=Double.POSITIVE_INFINITY; return base; }
            base.optionIndex[r]=oi; base.distance+=o.distance;
            jobs.add(new Job(r,o.chargingTime,Math.min(o.latestDeparture,CData.lastChargingPeriod+1.0)));
        }

        // A greedy success is already a constructive proof of feasibility.  This
        // very cheap short-circuit avoids entering DFS for the easy majority.
        ScheduleResult greedy=greedySchedule(routes,optionIdx);
        if (greedy.feasible) return greedy;

        jobs.sort(Comparator.comparingDouble((Job j)->j.deadline).thenComparingDouble(j->-j.duration));
        int B=Math.max(1,CData.B);
        double[] load=new double[B]; Arrays.fill(load,CData.firstChargingPeriod);

        // Necessary cumulative-capacity test.  If it fails, no assignment of the
        // remaining jobs to identical chargers can meet all deadlines.
        if (!prefixCapacityFeasible(0,jobs,load)) return greedy;

        int[] assign=new int[n]; Arrays.fill(assign,-1);
        double[] starts=new double[n], finishes=new double[n];
        SearchContext ctx=new SearchContext(n,B,nodeLimit);
        boolean ok=dfsAssign(0,jobs,load,assign,starts,finishes,ctx);
        greedy.dfsNodes=ctx.nodes;
        greedy.budgetExceeded=ctx.budgetExceeded;

        if (ok) {
            base.feasible=true; base.maxViolation=0; base.totalViolation=0;
            base.dfsNodes=ctx.nodes;
            for (int pos=0;pos<jobs.size();pos++) {
                int r=jobs.get(pos).route;
                base.charger[r]=assign[pos]; base.start[r]=starts[pos]; base.finish[r]=finishes[pos];
            }
            return base;
        }

        // Keep a useful violation estimate for search/reporting.  If the budget was
        // reached, callers can inspect budgetExceeded and must not interpret this as
        // a proof of infeasibility.
        return greedy;
    }

    private static final class SearchContext {
        final long nodeLimit;                 // <=0 means unlimited
        long nodes=0;
        boolean budgetExceeded=false;
        final HashSet<StateKey> failedStates=new HashSet<>();
        final int[][] machineOrder;

        SearchContext(int n,int B,long nodeLimit) {
            this.nodeLimit=nodeLimit;
            this.machineOrder=new int[Math.max(1,n)+1][Math.max(1,B)];
        }
    }

    /** Canonical state modulo permutation of identical chargers. */
    private static final class StateKey {
        final int pos;
        final long[] loads;
        final int hash;

        StateKey(int pos,double[] load) {
            this.pos=pos;
            double[] x=load.clone();
            Arrays.sort(x);
            loads=new long[x.length];
            int h=31+pos;
            for(int i=0;i<x.length;i++) {
                loads[i]=Double.doubleToLongBits(x[i]);
                h=31*h+Long.hashCode(loads[i]);
            }
            hash=h;
        }
        @Override public int hashCode(){return hash;}
        @Override public boolean equals(Object o){
            if(this==o)return true;
            if(!(o instanceof StateKey))return false;
            StateKey k=(StateKey)o;
            return pos==k.pos && Arrays.equals(loads,k.loads);
        }
    }

    private static boolean dfsAssign(int pos, List<Job> jobs, double[] load,
                                     int[] assign, double[] starts, double[] finishes,
                                     SearchContext ctx) {
        if (pos==jobs.size()) return true;
        ctx.nodes++;
        if (ctx.nodeLimit>0 && ctx.nodes>ctx.nodeLimit) {
            ctx.budgetExceeded=true;
            return false;
        }

        StateKey key=new StateKey(pos,load);
        if (ctx.failedStates.contains(key)) return false;
        if (!prefixCapacityFeasible(pos,jobs,load)) {
            ctx.failedStates.add(key);
            return false;
        }

        Job j=jobs.get(pos);
        int[] order=ctx.machineOrder[pos];
        for(int b=0;b<load.length;b++)order[b]=b;
        // B is small (6 in R101-50): primitive insertion sort is substantially
        // cheaper than allocating Integer[] and invoking TimSort at every DFS node.
        for(int i=1;i<load.length;i++){
            int v=order[i],k=i-1;
            while(k>=0 && (load[order[k]]>load[v]+EPS ||
                    (Math.abs(load[order[k]]-load[v])<=EPS && order[k]>v))){
                order[k+1]=order[k];k--;
            }
            order[k+1]=v;
        }

        double lastTried=Double.NaN;
        for (int bb=0;bb<load.length;bb++) {
            int b=order[bb];
            if (!Double.isNaN(lastTried) && Math.abs(load[b]-lastTried)<=EPS) continue; // symmetric machines
            lastTried=load[b];
            double f=load[b]+j.duration;
            if (f>j.deadline+EPS) continue;
            double old=load[b]; load[b]=f; assign[pos]=b; starts[pos]=old; finishes[pos]=f;
            if (dfsAssign(pos+1,jobs,load,assign,starts,finishes,ctx)) return true;
            load[b]=old; assign[pos]=-1;
            if (ctx.budgetExceeded) return false;
        }
        ctx.failedStates.add(key);
        return false;
    }

    /**
     * Necessary cumulative processing-capacity test for all remaining EDD prefixes.
     * For every deadline D, jobs due by D must fit into the sum of each charger's
     * residual capacity before D.
     */
    private static boolean prefixCapacityFeasible(int pos,List<Job> jobs,double[] load) {
        double required=0.0;
        for(int k=pos;k<jobs.size();k++) {
            required+=jobs.get(k).duration;
            double d=jobs.get(k).deadline;
            // It is sufficient to check the last job of each equal-deadline block.
            if(k+1<jobs.size() && Math.abs(jobs.get(k+1).deadline-d)<=EPS) continue;
            double capacity=0.0;
            for(double x:load) capacity+=Math.max(0.0,d-x);
            if(required>capacity+EPS) return false;
        }
        return true;
    }

    /**
     * Jointly choose one nondominated option per route and schedule charging.
     * For small option products this is exact for the fixed customer sequences;
     * otherwise it uses multistart + single-option repair with budgeted fixed-vector
     * checks so one pathological charging assignment cannot dominate AILS runtime.
     */
    public static ScheduleResult optimizeOptions(List<CRoute> routes, boolean apply) {
        if (routes.isEmpty()) return new ScheduleResult(0);
        List<int[]> feasibleOptions=collectFeasibleOptions(routes);
        if (feasibleOptions==null) {
            ScheduleResult bad=evaluateCurrent(routes); bad.feasible=false; return bad;
        }
        long product=optionProduct(feasibleOptions);
        ScheduleResult best;
        if (product<=EXACT_OPTION_COMBINATION_LIMIT) best=exactOptionEnumeration(routes,feasibleOptions);
        else best=heuristicOptionSearch(routes,feasibleOptions,
                HEURISTIC_SEED_DFS_LIMIT,HEURISTIC_REPAIR_DFS_LIMIT,
                HEURISTIC_FINAL_DFS_LIMIT,HEURISTIC_REPAIR_PASSES);
        applyIfFeasible(routes,best,apply);
        return best;
    }

    /**
     * Fully bounded joint option search for use inside AILS.  Unlike optimizeOptions(),
     * this routine never launches the unbounded exact option enumeration.  It is meant
     * for per-iteration screening, where a missed feasible schedule is preferable to a
     * multi-minute stall.  The returned budgetExceeded flag makes that uncertainty
     * explicit.
     */
    public static ScheduleResult optimizeOptionsWithBudget(List<CRoute> routes, boolean apply,
                                                            long seedLimit,long repairLimit,
                                                            long finalLimit,int repairPasses) {
        if (routes.isEmpty()) return new ScheduleResult(0);
        List<int[]> feasibleOptions=collectFeasibleOptions(routes);
        if (feasibleOptions==null) {
            ScheduleResult bad=evaluateCurrent(routes); bad.feasible=false; return bad;
        }
        ScheduleResult best=heuristicOptionSearch(routes,feasibleOptions,
                Math.max(1L,seedLimit),Math.max(1L,repairLimit),Math.max(1L,finalLimit),
                Math.max(1,repairPasses));
        applyIfFeasible(routes,best,apply);
        return best;
    }


    /**
     * V3.2 elite-incumbent refinement.  The caller supplies an already feasible
     * route-option schedule (normally produced by the V3.1 coordinator).  A bounded
     * best-first product search then tries to reduce distance by coordinated changes
     * on several routes.  Because a feasible upper bound is available from the start,
     * all states whose distance cannot improve it are pruned immediately.
     */
    public static ScheduleResult improveFeasibleOptionsBestFirst(List<CRoute> routes,
                                                                 ScheduleResult warmStart,
                                                                 boolean apply,
                                                                 long optionStateLimit,
                                                                 long fixedDfsLimit,
                                                                 long totalFixedDfsLimit,
                                                                 long timeLimitMillis) {
        if(routes.isEmpty()) return new ScheduleResult(0);
        if(warmStart==null || !warmStart.feasible) return warmStart;
        List<int[]> feasibleOptions=collectFeasibleOptions(routes);
        if(feasibleOptions==null) return warmStart;
        long deadlineNanos=timeLimitMillis<=0?Long.MAX_VALUE:
                System.nanoTime()+Math.max(1L,timeLimitMillis)*1_000_000L;
        ScheduleResult refined=bestFirstOptionSearch(routes,feasibleOptions,warmStart,
                Math.max(1L,optionStateLimit),Math.max(1L,fixedDfsLimit),
                Math.max(1L,totalFixedDfsLimit),deadlineNanos);
        ScheduleResult best=betterFinal(refined,warmStart)?refined:warmStart;
        applyIfFeasible(routes,best,apply);
        return best;
    }

    /**
     * V3.2 coordinator.  It first runs the robust V3.1 bounded multistart repair,
     * then explores route-option vectors in nondecreasing total distance using a
     * best-first product search.  This second phase can make coordinated changes
     * on several routes, which the single-option repair in V3.1 can miss.
     *
     * The search is bounded by optionStateLimit and every fixed-vector charging
     * check is itself bounded by fixedDfsLimit, so the old DFS explosion cannot
     * reappear.  Any returned feasible solution is constructively validated.
     */
    public static ScheduleResult optimizeOptionsEnhancedWithBudget(List<CRoute> routes, boolean apply,
                                                                    long seedLimit,long repairLimit,
                                                                    long finalLimit,int repairPasses,
                                                                    long optionStateLimit,long fixedDfsLimit,
                                                                    long totalFixedDfsLimit) {
        if (routes.isEmpty()) return new ScheduleResult(0);
        List<int[]> feasibleOptions=collectFeasibleOptions(routes);
        if (feasibleOptions==null) {
            ScheduleResult bad=evaluateCurrent(routes); bad.feasible=false; return bad;
        }

        ScheduleResult incumbent=heuristicOptionSearch(routes,feasibleOptions,
                Math.max(1L,seedLimit),Math.max(1L,repairLimit),Math.max(1L,finalLimit),
                Math.max(1,repairPasses));

        // The diagnostic/public enhanced routine is allowed to continue even when
        // the V3.1 warm start is infeasible.  Production AILS does NOT call this
        // broad path; it uses improveFeasibleOptionsBestFirst() only after a validated
        // new incumbent has already been constructed.
        ScheduleResult enhanced=bestFirstOptionSearch(routes,feasibleOptions,
                (incumbent!=null && incumbent.feasible)?incumbent:null,
                Math.max(1L,optionStateLimit),Math.max(1L,fixedDfsLimit),
                Math.max(1L,totalFixedDfsLimit),Long.MAX_VALUE);
        ScheduleResult best=betterFinal(enhanced,incumbent)?enhanced:incumbent;
        applyIfFeasible(routes,best,apply);
        return best;
    }

    private static final class OptionState {
        final int[] pos;
        final double distance;
        final int hash;
        OptionState(int[] pos,double distance) {
            this.pos=pos; this.distance=distance; this.hash=Arrays.hashCode(pos);
        }
        @Override public int hashCode(){return hash;}
        @Override public boolean equals(Object o){
            return o instanceof OptionState && Arrays.equals(pos,((OptionState)o).pos);
        }
    }

    /** Sort each route's feasible options by increasing route distance. */
    private static int[][] sortOptionsByDistance(List<CRoute> routes,List<int[]> feas) {
        int[][] out=new int[feas.size()][];
        for(int r=0;r<feas.size();r++) {
            Integer[] box=new Integer[feas.get(r).length];
            for(int i=0;i<box.length;i++)box[i]=feas.get(r)[i];
            final CRoute route=routes.get(r);
            Arrays.sort(box,(a,b)->{
                CRouteOption x=route.options.get(a),y=route.options.get(b);
                int c=Double.compare(x.distance,y.distance);
                if(c!=0)return c;
                c=Double.compare(x.chargingTime,y.chargingTime);
                if(c!=0)return c;
                return -Double.compare(x.latestDeparture,y.latestDeparture);
            });
            out[r]=new int[box.length];
            for(int i=0;i<box.length;i++)out[r][i]=box[i];
        }
        return out;
    }

    /**
     * Enumerate low-distance route-option combinations with a priority queue.
     * Starting from the minimum-distance option of every route, a neighbor advances
     * exactly one route to its next-more-expensive option.  Hence every option vector
     * is reachable and the queue exposes vectors in nondecreasing total distance.
     */
    private static ScheduleResult bestFirstOptionSearch(List<CRoute> routes,List<int[]> feas,
                                                        ScheduleResult initialBest,
                                                        long optionStateLimit,long fixedDfsLimit,
                                                        long totalFixedDfsLimit,long deadlineNanos) {
        final int n=routes.size();
        int[][] sorted=sortOptionsByDistance(routes,feas);
        int[] zero=new int[n];
        double startDistance=0.0;
        for(int r=0;r<n;r++) startDistance+=routes.get(r).options.get(sorted[r][0]).distance;

        PriorityQueue<OptionState> pq=new PriorityQueue<>((a,b)->{
            int c=Double.compare(a.distance,b.distance);
            if(c!=0)return c;
            for(int i=0;i<a.pos.length;i++){
                c=Integer.compare(a.pos[i],b.pos[i]); if(c!=0)return c;
            }
            return 0;
        });
        HashSet<OptionState> seen=new HashSet<>();
        OptionState root=new OptionState(zero,startDistance);
        pq.add(root);seen.add(root);

        ScheduleResult best=(initialBest!=null && initialBest.feasible)?initialBest.copy():null;
        boolean anyBudgetExceeded=initialBest!=null && initialBest.budgetExceeded;
        long examined=0;
        long totalFixedDfsNodes=0;

        while(!pq.isEmpty() && examined<optionStateLimit) {
            if(System.nanoTime()>=deadlineNanos){ anyBudgetExceeded=true; break; }
            OptionState st=pq.poll();
            if(best!=null && st.distance>=best.distance-EPS) break;
            examined++;

            int[] optionIdx=new int[n];
            for(int r=0;r<n;r++)optionIdx[r]=sorted[r][st.pos[r]];

            ScheduleResult s=greedySchedule(routes,optionIdx);
            if(!s.feasible && CData.B>1) {
                if(System.nanoTime()>=deadlineNanos){ anyBudgetExceeded=true; break; }
                long remaining=totalFixedDfsLimit-totalFixedDfsNodes;
                if(remaining<=0) { anyBudgetExceeded=true; break; }
                long thisLimit=Math.max(1L,Math.min(fixedDfsLimit,remaining));
                s=scheduleFixedOptionsWithBudget(routes,optionIdx,thisLimit);
                totalFixedDfsNodes+=s.dfsNodes;
                anyBudgetExceeded|=s.budgetExceeded;
            }
            if(s.feasible && (best==null || s.distance<best.distance-EPS)) best=s;

            // Generate every one-coordinate successor whose distance can still beat
            // the incumbent.  Multi-route coordinated moves arise naturally after
            // multiple successor steps and are not restricted to single-option repair.
            for(int r=0;r<n;r++) {
                int p=st.pos[r];
                if(p+1>=sorted[r].length)continue;
                double oldD=routes.get(r).options.get(sorted[r][p]).distance;
                double newD=routes.get(r).options.get(sorted[r][p+1]).distance;
                double nd=st.distance-oldD+newD;
                if(best!=null && nd>=best.distance-EPS)continue;
                int[] np=st.pos.clone();np[r]++;
                OptionState ns=new OptionState(np,nd);
                if(seen.add(ns))pq.add(ns);
            }
        }

        ScheduleResult out=best;
        if(out==null) {
            out=initialBest==null?evaluateCurrent(routes):initialBest;
        }
        out.optionStates=Math.max(out.optionStates,examined);
        out.optionDfsNodes=Math.max(out.optionDfsNodes,totalFixedDfsNodes);
        if(!out.feasible && anyBudgetExceeded)out.budgetExceeded=true;
        return out;
    }

    private static List<int[]> collectFeasibleOptions(List<CRoute> routes) {
        List<int[]> feasibleOptions=new ArrayList<>();
        for (CRoute r:routes) {
            ArrayList<Integer> ids=new ArrayList<>();
            for (int i=0;i<r.options.size();i++) if (r.options.get(i).isPhysicalFeasible()) ids.add(i);
            if (ids.isEmpty()) return null;
            int[] a=new int[ids.size()]; for (int i=0;i<a.length;i++) a[i]=ids.get(i);
            feasibleOptions.add(a);
        }
        return feasibleOptions;
    }

    private static long optionProduct(List<int[]> feasibleOptions) {
        long product=1;
        for(int[] a:feasibleOptions) {
            if (product>EXACT_OPTION_COMBINATION_LIMIT/a.length) return EXACT_OPTION_COMBINATION_LIMIT+1;
            product*=a.length;
        }
        return product;
    }

    private static void applyIfFeasible(List<CRoute> routes,ScheduleResult best,boolean apply) {
        // Never overwrite the current route options with an unverified/unknown vector.
        if (apply && best!=null && best.feasible && best.optionIndex.length==routes.size()) {
            for (int r=0;r<routes.size();r++) if (best.optionIndex[r]>=0) routes.get(r).selectOption(best.optionIndex[r]);
        }
    }

    private static ScheduleResult exactOptionEnumeration(List<CRoute> routes,List<int[]> feas) {
        int n=routes.size();
        double[] minRemain=new double[n+1];
        for (int r=n-1;r>=0;r--) {
            double m=Double.POSITIVE_INFINITY;
            for (int oi:feas.get(r)) m=Math.min(m,routes.get(r).options.get(oi).distance);
            minRemain[r]=minRemain[r+1]+m;
        }
        int[] cur=new int[n]; Arrays.fill(cur,-1);
        BestHolder h=new BestHolder();
        enumerate(0,0.0,routes,feas,minRemain,cur,h);
        if (h.best!=null) return h.best;
        // No feasible combination in the exact enumeration: use the heuristic only
        // to obtain a useful violation measure.  The exact conclusion remains that
        // no feasible combination exists within this enumerated option set.
        ScheduleResult fallback=heuristicOptionSearch(routes,feas,
                HEURISTIC_SEED_DFS_LIMIT,HEURISTIC_REPAIR_DFS_LIMIT,
                HEURISTIC_FINAL_DFS_LIMIT,HEURISTIC_REPAIR_PASSES);
        // Exact enumeration above exhausted all option vectors, so infeasibility is
        // proved even if this fallback violation estimator happened to hit a budget.
        if(!fallback.feasible) fallback.budgetExceeded=false;
        return fallback;
    }
    private static final class BestHolder { ScheduleResult best; double bestDistance=Double.POSITIVE_INFINITY; }
    private static void enumerate(int r,double dist,List<CRoute> routes,List<int[]> feas,double[] minRemain,int[] cur,BestHolder h) {
        if (dist+minRemain[r]>=h.bestDistance-EPS) return;
        if (r==routes.size()) {
            ScheduleResult s=exactScheduleFixedOptions(routes,cur);
            if (s.feasible && s.distance<h.bestDistance-EPS) { h.bestDistance=s.distance; h.best=s; }
            return;
        }
        Integer[] ids=new Integer[feas.get(r).length]; for (int i=0;i<ids.length;i++) ids[i]=feas.get(r)[i];
        Arrays.sort(ids,Comparator.comparingDouble(i->routes.get(r).options.get(i).distance));
        for (int oi:ids) {
            cur[r]=oi;
            enumerate(r+1,dist+routes.get(r).options.get(oi).distance,routes,feas,minRemain,cur,h);
        }
        cur[r]=-1;
    }

    private static ScheduleResult heuristicOptionSearch(List<CRoute> routes,List<int[]> feas,
                                                        long seedLimit,long repairLimit,
                                                        long finalLimit,int repairPasses) {
        double[] weights={0,0.02,0.05,0.1,0.25,0.5,1,2,5,10};
        ArrayList<int[]> starts=new ArrayList<>();
        HashSet<String> startKeys=new HashSet<>();

        int[] current=new int[routes.size()];
        for (int r=0;r<routes.size();r++) {
            int x=routes.get(r).selectedOptionIndex;
            if (!contains(feas.get(r),x)) x=feas.get(r)[0];
            current[r]=x;
        }
        addUniqueStart(starts,startKeys,current);

        for (double w:weights) {
            int[] x=new int[routes.size()];
            for (int r=0;r<routes.size();r++) {
                int best=feas.get(r)[0]; double bs=Double.POSITIVE_INFINITY;
                for (int oi:feas.get(r)) {
                    CRouteOption o=routes.get(r).options.get(oi);
                    double sc=o.distance+w*o.chargingTime;
                    if (sc<bs-EPS) {bs=sc;best=oi;}
                }
                x[r]=best;
            }
            addUniqueStart(starts,startKeys,x);
        }

        ScheduleResult best=null;
        boolean anyBudgetExceeded=false;
        for (int[] seed:starts) {
            int[] x=seed.clone();
            ScheduleResult cur=scheduleFixedOptionsWithBudget(routes,x,seedLimit);
            anyBudgetExceeded |= cur.budgetExceeded;

            for (int pass=0;pass<repairPasses;pass++) {
                int bestR=-1,bestO=-1; ScheduleResult bestMove=null;
                ScheduleResult currentGreedy=greedySchedule(routes,x);
                for (int r=0;r<routes.size();r++) for (int oi:feas.get(r)) {
                    if (oi==x[r]) continue;
                    int old=x[r]; x[r]=oi;
                    ScheduleResult s=greedySchedule(routes,x);
                    x[r]=old;
                    if (betterRepair(s,bestMove)) {bestMove=s;bestR=r;bestO=oi;}
                }
                if (bestMove==null || !betterRepair(bestMove,currentGreedy)) break;

                x[bestR]=bestO;
                cur=scheduleFixedOptionsWithBudget(routes,x,repairLimit);
                anyBudgetExceeded |= cur.budgetExceeded;
                if (cur.feasible) {
                    // Once feasible, try only distance-decreasing single-option changes.
                    // Greedy feasibility is accepted immediately; an expensive DFS is
                    // attempted only when the greedy conflict is small.
                    boolean improved=false;
                    outer:
                    for (int rr=0;rr<routes.size();rr++) for (int oi:feas.get(rr)) {
                        if (oi==x[rr]) continue;
                        int old=x[rr]; x[rr]=oi;
                        ScheduleResult g=greedySchedule(routes,x);
                        if (g.distance<cur.distance-EPS) {
                            ScheduleResult s=g;
                            if(!g.feasible && g.maxViolation<=5.0+EPS) {
                                s=scheduleFixedOptionsWithBudget(routes,x,repairLimit);
                                anyBudgetExceeded |= s.budgetExceeded;
                            }
                            if (s.feasible && s.distance<cur.distance-EPS) {
                                cur=s; improved=true; break outer; // keep x[rr]=oi
                            }
                        }
                        x[rr]=old;
                    }
                    if (!improved) break;
                }
            }

            cur=scheduleFixedOptionsWithBudget(routes,x,finalLimit);
            anyBudgetExceeded |= cur.budgetExceeded;
            if (betterFinal(cur,best)) best=cur;
        }
        ScheduleResult out=best==null?evaluateCurrent(routes):best;
        if(!out.feasible && anyBudgetExceeded) out.budgetExceeded=true;
        return out;
    }

    private static void addUniqueStart(List<int[]> starts,Set<String> keys,int[] x) {
        String k=Arrays.toString(x);
        if(keys.add(k)) starts.add(x.clone());
    }

    private static boolean betterRepair(ScheduleResult a,ScheduleResult b) {
        if (a==null) return false; if (b==null) return true;
        if (a.maxViolation<b.maxViolation-EPS) return true;
        if (a.maxViolation>b.maxViolation+EPS) return false;
        if (a.totalViolation<b.totalViolation-EPS) return true;
        if (a.totalViolation>b.totalViolation+EPS) return false;
        return a.distance<b.distance-EPS;
    }
    private static boolean betterFinal(ScheduleResult a,ScheduleResult b) {
        if (a==null) return false; if (b==null) return true;
        if (a.feasible!=b.feasible) return a.feasible;
        if (a.feasible) return a.distance<b.distance-EPS;
        return betterRepair(a,b);
    }
    private static boolean contains(int[] a,int x) { for(int v:a) if(v==x) return true; return false; }
}
