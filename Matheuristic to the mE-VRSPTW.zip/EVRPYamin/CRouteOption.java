package EVRPYamin;

import java.util.ArrayList;

/** One nondominated multigraph realization of a fixed customer sequence. */
public class CRouteOption {
    public double distance;
    public double energy;
    public double chargingTime;
    public double latestDeparture;
    public double lateness;
    public double routeEndTime;
    public ArrayList<Integer> arcTypes = new ArrayList<>(); // 0 Euclidean, 1 Manhattan

    public boolean isTimeFeasible() { return lateness <= 1e-8; }
    public boolean isEnergyFeasible() { return energy <= CData.E + 1e-8; }
    public boolean isPhysicalFeasible() { return isTimeFeasible() && isEnergyFeasible(); }
    /** Energy excess measured in percentage points of battery capacity (e.g., 4.5 = 4.5%). */
    public double energyViolationPercent() {
        if (!Double.isFinite(energy) || CData.E <= 0) return Double.POSITIVE_INFINITY;
        return Math.max(0.0, (energy - CData.E) / CData.E * 100.0);
    }

    public CRouteOption copy() {
        CRouteOption o = new CRouteOption();
        o.distance = distance; o.energy = energy; o.chargingTime = chargingTime;
        o.latestDeparture = latestDeparture; o.lateness = lateness; o.routeEndTime = routeEndTime;
        o.arcTypes = new ArrayList<>(arcTypes);
        return o;
    }

    @Override public String toString() {
        return String.format(java.util.Locale.US,
                "Option{dist=%.1f, energy=%.2f, charge=%.0f, latest=%.1f, late=%.1f, arcs=%s}",
                distance, energy, chargingTime, latestDeparture, lateness, arcTypes);
    }
}
