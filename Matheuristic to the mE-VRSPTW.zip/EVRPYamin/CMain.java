package EVRPYamin;

/** Command-line runner. */
public class CMain {
    public static void main(String[] args) throws Exception {
        if(args.length<2){
            System.out.println("Usage: java EVRPYamin.CMain <instance> <NC> [iterations=2000] [B_override=0]");
            System.out.println("Example: java EVRPYamin.CMain C101 25");
            return;
        }
        String file=args[0];
        String NC=args[1];

        int iterations=args.length>2?Integer.parseInt(args[2]):2000;
        int bOverride=args.length>3?Integer.parseInt(args[3]):0;

        String dataDir="/home/wwq/projects/def-adulyasa/wwq/Yamin_Instance/";
        file=dataDir+file+"-"+NC+".xml";

        CData.read(file,1.0);
        if(bOverride>0)CData.B=bOverride;
        CData.penaltyDepot=1.0;CData.penaltyEnergy=1.0;CData.lambda=0.0;
        CData.energyRelaxationFactor=1.10;
        CData.print();
        System.out.println("Algorithm: V3.3-I (10% energy strategic oscillation + integrated route-option-charging SP)");
        CDominance.preprocess();
        CDominance.printSummary();

        CAILS.Run(iterations,0.25,0.35,0.12);
        if(!CSolution.ValidateCustomerCoverage())throw new IllegalStateException("Invalid customer coverage in final solution");
        System.out.println("\nFINAL");CSolution.Show();
        System.out.println("Best feasible distance = "+CSaveSolution.best_route_depot_feasible_cost);
    }
}
