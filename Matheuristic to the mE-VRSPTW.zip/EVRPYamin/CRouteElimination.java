package EVRPYamin;

import java.util.*;

/**
 * Route-elimination / route-removal operator with regret-2 reinsertion.
 * It is used both as an improving neighborhood and as a diversification move.
 */
public final class CRouteElimination {
    private CRouteElimination() {}
    private static final double EPS = 1e-9;
    private static final int MAX_INSERTION_POSITIONS = 14;

    private static final class Insertion {
        int customer;
        int row;              // -1 means new singleton route
        CRoute route;
        double bestScore;
        double secondScore;
        double regret;
    }

    /** Try to remove one of the smallest routes and accept only a search-cost improvement. */
    public static boolean TryImprove(int maxRoutesToTry) {
        if (CSolution.Route.size() <= 1) return false;
        double incumbent = CSolution.searchCost;
        ArrayList<Integer> order = routeOrderBySize();
        ArrayList<CRoute> best = null;
        double bestScore = incumbent;

        int tried = 0;
        for (int row : order) {
            if (tried++ >= Math.max(1, maxRoutesToTry)) break;
            ArrayList<CRoute> candidate = eliminateRoute(CSolution.Route, row, false);
            if (candidate == null) continue;
            double score = CSolution.ComputeSearchScore(candidate);
            if (score < bestScore - EPS) {
                bestScore = score;
                best = candidate;
            }
        }

        if (best != null) {
            CSolution.Route = best;
            CSolution.UpdateInformation();
            return true;
        }
        return false;
    }

    /** Random route-removal perturbation. Returns true only when a full reinsertion succeeds. */
    public static boolean PerturbRandom(Random ran, int maxTries) {
        if (CSolution.Route.size() <= 1) return false;
        ArrayList<Integer> ids = new ArrayList<>();
        for (int i=0;i<CSolution.Route.size();i++) ids.add(i);
        Collections.shuffle(ids, ran);
        int lim = Math.min(ids.size(), Math.max(1, maxTries));
        for (int k=0;k<lim;k++) {
            ArrayList<CRoute> candidate = eliminateRoute(CSolution.Route, ids.get(k), false);
            if (candidate != null) {
                CSolution.Route = candidate;
                CSolution.UpdateInformation();
                return true;
            }
        }
        return false;
    }

    /**
     * Regret-2 repair. If allowNewRoute=false all removed customers must fit into existing routes.
     * The input list is not modified.
     */
    public static ArrayList<CRoute> RepairByRegret(List<CRoute> base, Collection<Integer> customers,
                                                   boolean allowNewRoute) {
        ArrayList<CRoute> work = CSolution.CopyRouteList(base);
        ArrayList<Integer> unassigned = new ArrayList<>(customers);

        while (!unassigned.isEmpty()) {
            Insertion chosen = null;
            for (int c : unassigned) {
                Insertion ins = bestInsertion(work, c, allowNewRoute);
                if (ins == null) continue;
                if (chosen == null
                        || ins.regret > chosen.regret + EPS
                        || (Math.abs(ins.regret - chosen.regret) <= EPS && ins.bestScore < chosen.bestScore - EPS)) {
                    chosen = ins;
                }
            }
            if (chosen == null) return null;

            if (chosen.row < 0) work.add(chosen.route);
            else work.set(chosen.row, chosen.route);
            unassigned.remove(Integer.valueOf(chosen.customer));
        }
        return work;
    }

    private static ArrayList<CRoute> eliminateRoute(List<CRoute> source, int row, boolean allowNewRoute) {
        if (row < 0 || row >= source.size() || source.size() <= 1) return null;
        CRoute removedRoute = source.get(row);
        ArrayList<Integer> removed = new ArrayList<>();
        for (int p=1;p<removedRoute.path.size()-1;p++) removed.add(removedRoute.path.get(p));
        if (removed.isEmpty()) return null;

        ArrayList<CRoute> base = new ArrayList<>();
        for (int r=0;r<source.size();r++) if (r != row) base.add(source.get(r).copy());
        ArrayList<CRoute> repaired = RepairByRegret(base, removed, allowNewRoute);
        if (repaired == null) return null;
        if (!allowNewRoute && repaired.size() >= source.size()) return null;
        return repaired;
    }

    private static final class PosCandidate {
        int row,pos; double approx;
        PosCandidate(int row,int pos,double approx){this.row=row;this.pos=pos;this.approx=approx;}
    }

    private static Insertion bestInsertion(ArrayList<CRoute> work, int c, boolean allowNewRoute) {
        double best = Double.POSITIVE_INFINITY, second = Double.POSITIVE_INFINITY;
        int bestRow = Integer.MIN_VALUE;
        CRoute bestRoute = null;

        ArrayList<PosCandidate> posCandidates=new ArrayList<>();
        double demand=CData.nodes.get(c).demand;
        for (int r=0;r<work.size();r++) {
            CRoute old=work.get(r);
            if(old.load+demand>CData.Q+EPS)continue;
            for(int pos=1;pos<old.path.size();pos++){
                int a=old.path.get(pos-1), b=old.path.get(pos);
                double approx=minDist(a,c)+minDist(c,b)-minDist(a,b);
                posCandidates.add(new PosCandidate(r,pos,approx));
            }
        }
        posCandidates.sort(Comparator.comparingDouble(pc->pc.approx));
        int lim=Math.min(MAX_INSERTION_POSITIONS,posCandidates.size());
        for(int z=0;z<lim;z++){
            PosCandidate pc=posCandidates.get(z);
            CRoute old=work.get(pc.row);
            ArrayList<Integer> p=new ArrayList<>(old.path);p.add(pc.pos,c);
            CRoute nr=new CRoute();CEvaluationRoute.Run(p,nr);
            if(!Double.isFinite(nr.cost))continue;
            ArrayList<CRoute> temp=new ArrayList<>(work);temp.set(pc.row,nr);
            double score=CSolution.ComputeSearchScore(temp);
            if(score<best-EPS){second=best;best=score;bestRow=pc.row;bestRoute=nr;}
            else if(score<second-EPS)second=score;
        }

        if (allowNewRoute) {
            ArrayList<Integer> p = new ArrayList<>(Arrays.asList(0,c,0));
            CRoute nr = new CRoute();
            CEvaluationRoute.Run(p,nr);
            if (Double.isFinite(nr.cost)) {
                ArrayList<CRoute> temp = new ArrayList<>(work);
                temp.add(nr);
                double score = CSolution.ComputeSearchScore(temp);
                if (score < best - EPS) {
                    second = best; best = score; bestRow = -1; bestRoute = nr;
                } else if (score < second - EPS) second = score;
            }
        }

        if (bestRoute == null) return null;
        Insertion out = new Insertion();
        out.customer = c; out.row = bestRow; out.route = bestRoute;
        out.bestScore = best; out.secondScore = second;
        out.regret = Double.isFinite(second) ? second - best : 1e6;
        return out;
    }

    private static double minDist(int i,int j){
        return Math.min(CData.euclideanDistance[i][j],CData.manhattanDistance[i][j]);
    }

    private static ArrayList<Integer> routeOrderBySize() {
        ArrayList<Integer> ids = new ArrayList<>();
        for (int i=0;i<CSolution.Route.size();i++) ids.add(i);
        ids.sort(Comparator
                .comparingInt((Integer i)->CSolution.customerCount(CSolution.Route.get(i).path))
                .thenComparingDouble(i->CSolution.Route.get(i).travel_distance));
        return ids;
    }
}
