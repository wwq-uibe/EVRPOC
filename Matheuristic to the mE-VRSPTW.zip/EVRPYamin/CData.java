package EVRPYamin;

import java.io.File;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

/** Reader for the Yamín et al. XML instances. Java 8+. */
public final class CData {
    public static double Q;
    public static double E;
    public static String name;
    public static int B, numChargers, startDepotId, endDepotId;

    /** Search penalties / weights. */
    public static double penalty_init = 1.0;      // time-window violation penalty
    public static double penaltyDepot = 1.0;     // depot-schedule violation penalty
    public static double penaltyEnergy = 1.0;    // penalty per percentage point of route-energy excess
    public static double lambda = 0.0;           // route-level charging-time pressure

    /** V3.3 strategic oscillation: search routes may consume up to 110% of E. */
    public static double energyRelaxationFactor = 1.10;

    /** Charging data (minutes / kWh). */
    public static int firstChargingPeriod;
    public static int lastChargingPeriod;
    public static double[] chargingBreakpoints = new double[0]; // kWh, end of each piece
    public static double[] chargingRates = new double[0];       // kWh per minute

    public static List<CNode> nodes = new ArrayList<>();
    public static double[][] euclideanDistance, manhattanDistance;
    public static double[][] euclideanTime, manhattanTime;
    public static double[][] euclideanEnergy, manhattanEnergy;
    public static Map<Integer,Integer> indexById = new HashMap<>();

    private CData() {}

    public static void read(String filePath) throws Exception {
        read(filePath, 1.0);
    }

    public static void read(String filePath, double pInit) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        factory.setXIncludeAware(false);
        factory.setExpandEntityReferences(false);
        Document doc = factory.newDocumentBuilder().parse(new File(filePath));
        Element root = doc.getDocumentElement();

        Element info = child(root, "info");
        Element network = child(root, "network");
        Element fleet = child(root, "fleet");
        Element vehicleProfile = child(fleet, "vehicle_profile");
        Element vehicleCustom = child(vehicleProfile, "custom");

        String parsedName = value(info, "name");
        int xmlChargers = Integer.parseInt(value(info, "num_chargers"));
        double parsedQ = Double.parseDouble(value(vehicleProfile, "capacity"));
        if (parsedQ <= 0) throw new IllegalArgumentException("Invalid vehicle capacity: " + parsedQ);

        int parsedFirstCharging = Integer.parseInt(value(vehicleCustom, "first_charging_period"));
        int parsedLastCharging = Integer.parseInt(value(vehicleCustom, "last_charging_period"));
        double parsedE = Double.parseDouble(value(vehicleCustom, "energy_capacity")) / 100.0;
        if (parsedE <= 0) throw new IllegalArgumentException("Invalid energy capacity: " + parsedE);

        Element chargingFunction = child(vehicleCustom, "charging_function");
        List<Element> bpEls = children(chargingFunction, "breakpoint");
        if (bpEls.isEmpty()) throw new IllegalArgumentException("Missing charging-function breakpoints");
        double[] parsedBreakpoints = new double[bpEls.size()];
        double[] parsedRates = new double[bpEls.size()];
        for (int p = 0; p < bpEls.size(); p++) {
            parsedBreakpoints[p] = Double.parseDouble(value(bpEls.get(p), "energy_level")) / 100.0;
            // XML rate is in 0.01 kWh per one-minute charging period.
            parsedRates[p] = Double.parseDouble(value(bpEls.get(p), "recharging_rate")) / 100.0;
            if (parsedRates[p] <= 0) throw new IllegalArgumentException("Invalid charging rate at piece " + p);
        }

        Element nodeContainer = child(network, "nodes");
        ArrayList<CNode> customers = new ArrayList<>();
        ArrayList<CNode> depots = new ArrayList<>();
        for (Element el : children(nodeContainer, "node")) {
            int id = Integer.parseInt(el.getAttribute("id"));
            int type = Integer.parseInt(el.getAttribute("type"));
            Element tw = child(el, "tw");
            CNode node = new CNode();
            node.index = id;
            node.x = (int)Math.round(Double.parseDouble(value(el, "cx")));
            node.y = (int)Math.round(Double.parseDouble(value(el, "cy")));
            node.demand = (int)Math.round(Double.parseDouble(value(el, "load")));
            // Routing times in the XML are stored in tenths of a minute.
            node.early_time = Double.parseDouble(value(tw, "start")) / 10.0;
            node.due_time = Double.parseDouble(value(tw, "end")) / 10.0;
            if (type == 0) depots.add(node);
            else if (type == 1) customers.add(node);
            else throw new IllegalArgumentException("Unknown node type " + type + " at id=" + id);
        }
        if (depots.size() != 2) throw new IllegalArgumentException("Expected start/end depots; got " + depots.size());
        depots.sort(Comparator.comparingInt(n -> n.index));
        CNode start = depots.get(0), end = depots.get(1);
        if (start.x != end.x || start.y != end.y)
            throw new IllegalArgumentException("Start/end depots have different coordinates");
        customers.sort(Comparator.comparingInt(n -> n.index));

        ArrayList<CNode> ns = new ArrayList<>();
        ns.add(start);
        ns.addAll(customers);
        HashMap<Integer,Integer> index = new HashMap<>();
        for (int i = 0; i < ns.size(); i++) index.put(ns.get(i).index, i);

        int n = ns.size();
        double[][] euclidean = new double[n][n], manhattan = new double[n][n];
        double[][] euclideanTravelTime = new double[n][n], manhattanTravelTime = new double[n][n];
        double[][] euclideanConsumption = new double[n][n], manhattanConsumption = new double[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) {
            double dx = ns.get(i).x - ns.get(j).x, dy = ns.get(i).y - ns.get(j).y;
            euclidean[i][j] = truncateTenths(Math.hypot(dx, dy));
            manhattan[i][j] = truncateTenths(Math.abs(dx) + Math.abs(dy));
            // Speed = 60 km/h = 1 km/min.
            euclideanTravelTime[i][j] = euclidean[i][j];
            manhattanTravelTime[i][j] = manhattan[i][j];
            euclideanConsumption[i][j] = truncateHundredths(euclidean[i][j] * 0.175);
            manhattanConsumption[i][j] = truncateHundredths(manhattan[i][j] * 0.125);
        }

        // Infer service times from depot-customer / customer-depot links.
        Map<Integer,Map<Integer,Integer>> outward = new HashMap<>();
        Map<Integer,Map<Integer,Integer>> returns = new HashMap<>();
        Element links = child(network, "links");
        for (Element link : children(links, "link")) {
            int tail = Integer.parseInt(link.getAttribute("tail"));
            int head = Integer.parseInt(link.getAttribute("head"));
            boolean fromDepot = (tail == start.index && index.containsKey(head) && head != start.index);
            boolean toDepot = (head == end.index && index.containsKey(tail) && tail != start.index);
            if (!fromDepot && !toDepot) continue;
            int customer = fromDepot ? head : tail;
            int cost = Integer.parseInt(value(link, "travel_cost"));
            int time = Integer.parseInt(value(link, "travel_time"));
            Map<Integer,Map<Integer,Integer>> target = fromDepot ? outward : returns;
            Map<Integer,Integer> alternatives = target.computeIfAbsent(customer, k -> new HashMap<>());
            Integer previous = alternatives.putIfAbsent(cost, time);
            if (previous != null && previous != time)
                throw new IllegalArgumentException("Conflicting travel times for customer " + customer + " cost " + cost);
        }
        for (CNode customer : customers) {
            Map<Integer,Integer> out = outward.get(customer.index), back = returns.get(customer.index);
            if (out == null || back == null)
                throw new IllegalArgumentException("Missing depot links for customer " + customer.index);
            Set<Integer> inferred = new HashSet<>();
            for (Map.Entry<Integer,Integer> arc : out.entrySet()) {
                Integer returnTime = back.get(arc.getKey());
                if (returnTime != null) inferred.add(returnTime - arc.getValue());
            }
            if (inferred.size() != 1 || inferred.iterator().next() < 0)
                throw new IllegalArgumentException("Cannot infer unique service time for customer "
                        + customer.index + "; matching differences=" + inferred);
            customer.service_time = inferred.iterator().next() / 10.0;
        }

        name = parsedName;
        Q = parsedQ;
        E = parsedE;
        B = xmlChargers;
        numChargers = xmlChargers;
        firstChargingPeriod = parsedFirstCharging;
        lastChargingPeriod = parsedLastCharging;
        chargingBreakpoints = parsedBreakpoints;
        chargingRates = parsedRates;
        penalty_init = pInit;
        penaltyEnergy = 1.0;
        startDepotId = start.index;
        endDepotId = end.index;
        nodes = ns;
        indexById = index;
        euclideanDistance = euclidean;
        manhattanDistance = manhattan;
        euclideanTime = euclideanTravelTime;
        manhattanTime = manhattanTravelTime;
        euclideanEnergy = euclideanConsumption;
        manhattanEnergy = manhattanConsumption;
    }

    public static int customerCount() { return Math.max(0, nodes.size() - 1); }

    public static void print() {
        System.out.println("================ Yamin instance ================");
        System.out.println("Name: " + name);
        System.out.println("Customers: " + customerCount());
        System.out.println("Vehicle capacity Q: " + Q);
        System.out.println("Energy capacity E: " + E + " kWh");
        System.out.println("Search energy relaxation: " + String.format(Locale.US,"%.0f%%",100.0*(energyRelaxationFactor-1.0)));
        System.out.println("Chargers B: " + B);
        System.out.println("Charging horizon: " + firstChargingPeriod + ".." + lastChargingPeriod + " min");
        System.out.println("Charging breakpoints: " + Arrays.toString(chargingBreakpoints));
        System.out.println("Charging rates (kWh/min): " + Arrays.toString(chargingRates));
        System.out.println("Depot TW: [" + nodes.get(0).early_time + ", " + nodes.get(0).due_time + "] min");
        System.out.println("================================================");
    }

    private static double truncateHundredths(double x) {
        return Math.floor(x * 100.0 + 1e-9) / 100.0;
    }
    private static double truncateTenths(double x) {
        return Math.floor(x * 10.0 + 1e-9) / 10.0;
    }
    private static Element child(Element parent, String tag) {
        NodeList all = parent.getChildNodes();
        for (int i = 0; i < all.getLength(); i++) {
            org.w3c.dom.Node node = all.item(i);
            if (node instanceof Element && ((Element)node).getTagName().equals(tag)) return (Element)node;
        }
        throw new IllegalArgumentException("Missing <" + tag + "> in <" + parent.getTagName() + ">");
    }
    private static String value(Element parent, String tag) { return child(parent, tag).getTextContent().trim(); }
    private static List<Element> children(Element parent, String tag) {
        List<Element> result = new ArrayList<>();
        NodeList all = parent.getChildNodes();
        for (int i = 0; i < all.getLength(); i++) {
            org.w3c.dom.Node item = all.item(i);
            if (item instanceof Element && ((Element)item).getTagName().equals(tag)) result.add((Element)item);
        }
        return result;
    }
}
