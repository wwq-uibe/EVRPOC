package EVRPYamin;

import java.util.*;

/**
 * Cross-exchange between two different routes. Segments of length 1..3 are
 * exchanged; optional reversal of either segment is considered.
 */
public final class CCrossExchange {
    private CCrossExchange() {}
    private static final double EPS = 1e-9;

    public static boolean Run(ArrayList<ArrayList<Integer>> candidates) {
        double incumbent = CSolution.searchCost;
        Collections.shuffle(candidates, CLocalSearch1.ran);
        for (ArrayList<Integer> pair : candidates) {
            if (pair == null || pair.size() < 2) continue;
            int c1 = pair.get(0), c2 = pair.get(1);
            int r1 = CData.nodes.get(c1).GetRow(), r2 = CData.nodes.get(c2).GetRow();
            int p1 = CData.nodes.get(c1).GetCol(), p2 = CData.nodes.get(c2).GetCol();
            if (r1 < 0 || r2 < 0 || r1 == r2 || p1 < 1 || p2 < 1) continue;

            CRoute a = CSolution.Route.get(r1), b = CSolution.Route.get(r2);
            int max1 = Math.min(3, (a.path.size() - 1) - p1);
            int max2 = Math.min(3, (b.path.size() - 1) - p2);
            for (int l1 = 1; l1 <= max1; l1++) {
                double q1=0;for(int z=p1;z<p1+l1;z++)q1+=CData.nodes.get(a.path.get(z)).demand;
                for (int l2 = 1; l2 <= max2; l2++) {
                    if (l1 == 1 && l2 == 1) continue;
                    double q2=0;for(int z=p2;z<p2+l2;z++)q2+=CData.nodes.get(b.path.get(z)).demand;
                    if(a.load-q1+q2>CData.Q+1e-9 || b.load-q2+q1>CData.Q+1e-9)continue;
                    for (boolean rev1 : new boolean[]{false, true}) {
                        for (boolean rev2 : new boolean[]{false, true}) {
                            ArrayList<CRoute> candidate = buildSwap(r1, r2, p1, l1, p2, l2, rev1, rev2);
                            if (candidate == null) continue;
                            double score = CSolution.ComputeSearchScore(candidate);
                            if (score < incumbent - EPS) {
                                CSolution.Route = candidate;
                                CSolution.UpdateInformation();
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private static ArrayList<CRoute> buildSwap(int r1, int r2, int p1, int l1, int p2, int l2,
                                                boolean rev1, boolean rev2) {
        ArrayList<CRoute> temp = CSolution.CopyRouteList(CSolution.Route);
        CRoute a = temp.get(r1), b = temp.get(r2);
        if (p1 + l1 > a.path.size() - 1 || p2 + l2 > b.path.size() - 1) return null;

        ArrayList<Integer> s1 = new ArrayList<>(a.path.subList(p1, p1 + l1));
        ArrayList<Integer> s2 = new ArrayList<>(b.path.subList(p2, p2 + l2));
        if (rev1) Collections.reverse(s1);
        if (rev2) Collections.reverse(s2);

        ArrayList<Integer> np1 = new ArrayList<>(a.path);
        ArrayList<Integer> np2 = new ArrayList<>(b.path);
        np1.subList(p1, p1 + l1).clear();
        np2.subList(p2, p2 + l2).clear();
        np1.addAll(p1, s2);
        np2.addAll(p2, s1);
        if (np1.equals(a.path) && np2.equals(b.path)) return null;

        CRoute nr1 = new CRoute(), nr2 = new CRoute();
        CEvaluationRoute.Run(np1, nr1);
        CEvaluationRoute.Run(np2, nr2);
        if (!Double.isFinite(nr1.cost) || !Double.isFinite(nr2.cost)) return null;
        temp.set(r1, nr1);
        temp.set(r2, nr2);
        return temp;
    }
}
