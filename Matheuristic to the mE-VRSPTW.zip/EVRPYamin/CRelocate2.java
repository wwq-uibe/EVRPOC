package EVRPYamin;
import java.util.*;
/** Move cus2 immediately after cus1. */
public final class CRelocate2 {
    private CRelocate2() {}
    public static double Calculate(int cus1,int cus2,CRoute cr1,CRoute cr2) {
        if(cus1==cus2)return Double.POSITIVE_INFINITY;
        int r1=CData.nodes.get(cus1).GetRow(),r2=CData.nodes.get(cus2).GetRow(); if(r1<0||r2<0)return Double.POSITIVE_INFINITY;
        if(r1==r2){
            ArrayList<Integer> p=new ArrayList<>(CSolution.Route.get(r1).path); p.remove(Integer.valueOf(cus2)); int pos=p.indexOf(cus1); p.add(pos+1,cus2);
            CEvaluationRoute.Run(p,cr1); if(!Double.isFinite(cr1.cost))return Double.POSITIVE_INFINITY;
            return CSolution.ScoreAfterReplacement(r1,cr1,-1,null);
        }
        ArrayList<Integer> p1=new ArrayList<>(CSolution.Route.get(r1).path),p2=new ArrayList<>(CSolution.Route.get(r2).path);
        p1.add(p1.indexOf(cus1)+1,cus2); p2.remove(Integer.valueOf(cus2));
        CEvaluationRoute.Run(p1,cr1); CEvaluationRoute.Run(p2,cr2);
        if(!Double.isFinite(cr1.cost)||!Double.isFinite(cr2.cost))return Double.POSITIVE_INFINITY;
        if(CSolution.customerCount(p2)==0)cr2.isempty=true;
        return CSolution.ScoreAfterReplacement(r1,cr1,r2,cr2);
    }
    public static void UpdateCurSolution(int cus1,int cus2,CRoute cr1,CRoute cr2){CRelocated.UpdateCurSolution(cus1,cus2,cr1,cr2);}
}
