package EVRPYamin;
import java.util.*;
/** Split one customer into a singleton route. Useful for escaping time/energy bottlenecks. */
public final class CBreak {
    private CBreak() {}
    public static double Calculate(int cus,CRoute cr1,CRoute cr2){
        int r=CData.nodes.get(cus).GetRow(); if(r<0||CSolution.customerCount(CSolution.Route.get(r).path)<=1)return Double.POSITIVE_INFINITY;
        ArrayList<Integer>p1=new ArrayList<>(CSolution.Route.get(r).path);p1.remove(Integer.valueOf(cus));
        ArrayList<Integer>p2=new ArrayList<>(Arrays.asList(0,cus,0)); CEvaluationRoute.Run(p1,cr1);CEvaluationRoute.Run(p2,cr2);
        if(!Double.isFinite(cr1.cost)||!Double.isFinite(cr2.cost))return Double.POSITIVE_INFINITY; return CSolution.ScoreAfterAdd(r,cr1,cr2);
    }
    public static void UpdateCurSolution(int cus,CRoute cr1,CRoute cr2){int r=CData.nodes.get(cus).GetRow();CSolution.Route.set(r,cr1);CSolution.Route.add(cr2);CSolution.UpdateInformation();}
}
