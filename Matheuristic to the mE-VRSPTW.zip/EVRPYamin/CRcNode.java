package EVRPYamin;

public class CRcNode {
	public double max_right=0;
	public double max_wt=0;
	public double cur_range=0;
	public int chargeid=-1;

	public double cu_chargingtime=0;
	public boolean iscancharge=true;
	public double init_range=0;
	public double penaly_dis=0;
}
