package EVRPYamin;

import java.util.*;

/** Best-improvement VND with stronger route/segment neighborhoods. */
public final class CLocalSearch1 {
    private CLocalSearch1() {}
    private static final double EPS=1e-9;
    public static Random ran=new Random();
    public static boolean breakactive;

    /** One VND pass. Returns true if at least one move is accepted. */
    public static boolean Run(double pairSampleRatio,double breakRatio) {
        return Run(pairSampleRatio,breakRatio,true);
    }

    /**
     * strong=false runs only the inexpensive neighborhoods. Strong neighborhoods
     * are scheduled periodically by CAILS rather than after every perturbation.
     */
    public static boolean Run(double pairSampleRatio,double breakRatio,boolean strong) {
        boolean changed=false;

        // Cheap neighborhoods first.
        changed |= Run_Relocated(CLingyu.GetCandiCUSList(pairSampleRatio));
        changed |= Run_Swap(CLingyu.GetCandiCUSList(pairSampleRatio));
        changed |= Run_Relocated2(CLingyu.GetCandiCUSList(pairSampleRatio));
        changed |= Run_Exchange(CLingyu.GetCandiCUSList(pairSampleRatio));

        if(strong && !changed){
            changed |= CTwoOpt.Run();
            double orRatio=Math.max(0.03,Math.min(0.12,pairSampleRatio*0.35));
            double crossRatio=Math.max(0.02,Math.min(0.06,pairSampleRatio*0.18));
            if(!changed) changed |= COrOpt.Run(CLingyu.GetCandiCUSList(orRatio));
            if(!changed) changed |= CCrossExchange.Run(CLingyu.GetCandiCUSList(crossRatio));
            if(!changed) changed |= CRouteElimination.TryImprove(1);
        }

        // Splitting is kept as a last-resort feasibility/escape move because it can
        // increase the number of routes.
        breakactive=false;
        if(!changed){
            breakactive=Run_Break(CLingyu.GetBreakPoint(breakRatio));
            changed |= breakactive;
        }
        return changed;
    }

    public static boolean Run_Relocated(ArrayList<ArrayList<Integer>> cand) {
        double cur=CSolution.searchCost,best=cur;int bc1=-1,bc2=-1;CRoute br1=null,br2=null;
        for(ArrayList<Integer> p:cand){CRoute r1=new CRoute(),r2=new CRoute();double s=CRelocated.Calculate(p.get(0),p.get(1),r1,r2);if(s<best-EPS){best=s;bc1=p.get(0);bc2=p.get(1);br1=r1;br2=r2;}}
        if(br1!=null){CRelocated.UpdateCurSolution(bc1,bc2,br1,br2);return true;}return false;
    }
    public static boolean Run_Relocated2(ArrayList<ArrayList<Integer>> cand) {
        double cur=CSolution.searchCost,best=cur;int bc1=-1,bc2=-1;CRoute br1=null,br2=null;
        for(ArrayList<Integer> p:cand){CRoute r1=new CRoute(),r2=new CRoute();double s=CRelocate2.Calculate(p.get(0),p.get(1),r1,r2);if(s<best-EPS){best=s;bc1=p.get(0);bc2=p.get(1);br1=r1;br2=r2;}}
        if(br1!=null){CRelocate2.UpdateCurSolution(bc1,bc2,br1,br2);return true;}return false;
    }
    public static boolean Run_Swap(ArrayList<ArrayList<Integer>> cand) {
        double cur=CSolution.searchCost,best=cur;int bc1=-1,bc2=-1;CRoute br1=null,br2=null;
        for(ArrayList<Integer> p:cand){CRoute r1=new CRoute(),r2=new CRoute();double s=CSwap.Calculate(p.get(0),p.get(1),r1,r2);if(s<best-EPS){best=s;bc1=p.get(0);bc2=p.get(1);br1=r1;br2=r2;}}
        if(br1!=null){CSwap.UpdateCurSolution(bc1,bc2,br1,br2);return true;}return false;
    }
    public static boolean Run_Exchange(ArrayList<ArrayList<Integer>> cand) {
        double cur=CSolution.searchCost,best=cur;int bc1=-1,bc2=-1;CRoute br1=null,br2=null;
        for(ArrayList<Integer> p:cand){CRoute r1=new CRoute(),r2=new CRoute();double s=CExchange.Calculate(p.get(0),p.get(1),r1,r2);if(s<best-EPS){best=s;bc1=p.get(0);bc2=p.get(1);br1=r1;br2=r2;}}
        if(br1!=null){CExchange.UpdateCurSolution(bc1,bc2,br1,br2);return true;}return false;
    }
    public static boolean Run_Break(int[] x) {
        double cur=CSolution.searchCost,best=cur;int bc=-1;CRoute br1=null,br2=null;
        for(int c:x){CRoute r1=new CRoute(),r2=new CRoute();double s=CBreak.Calculate(c,r1,r2);if(s<best-EPS){best=s;bc=c;br1=r1;br2=r2;}}
        if(br1!=null){CBreak.UpdateCurSolution(bc,br1,br2);return true;}return false;
    }
}
