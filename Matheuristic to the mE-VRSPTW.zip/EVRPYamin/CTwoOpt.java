package EVRPYamin;

import java.util.*;

/** Intra-route 2-opt: first improving reversal of a contiguous customer segment. */
public final class CTwoOpt {
    private CTwoOpt() {}
    private static final double EPS = 1e-9;

    public static boolean Run() {
        double incumbent = CSolution.searchCost;
        // Randomize route order through a deterministic copy driven by the LS RNG.
        ArrayList<Integer> rows=new ArrayList<>();for(int r=0;r<CSolution.Route.size();r++)rows.add(r);
        Collections.shuffle(rows,CLocalSearch1.ran);
        for (int r : rows) {
            CRoute old = CSolution.Route.get(r);
            int m = old.path.size();
            for (int i = 1; i <= m - 3; i++) {
                for (int j = i + 1; j <= m - 2; j++) {
                    ArrayList<Integer> p = new ArrayList<>(old.path);
                    Collections.reverse(p.subList(i, j + 1));
                    CRoute nr = new CRoute();
                    CEvaluationRoute.Run(p, nr);
                    if (!Double.isFinite(nr.cost)) continue;
                    ArrayList<CRoute> temp = CSolution.CopyRouteList(CSolution.Route);
                    temp.set(r, nr);
                    double score = CSolution.ComputeSearchScore(temp);
                    if (score < incumbent - EPS) {
                        CSolution.Route = temp;
                        CSolution.UpdateInformation();
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
