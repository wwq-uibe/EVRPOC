package EVRPYamin;

import java.util.*;

/**
 * V3.3 feasibility restoration after a short strategic-oscillation excursion.
 * Energy-infeasible routes are repaired by customer relocation; if no reducing
 * relocation exists, one customer is split to a singleton route as a guaranteed
 * escape whenever that singleton is physically energy-feasible.
 */
public final class CEnergyRepair {
    private CEnergyRepair() {}
    private static final double EPS=1e-8;

    public static boolean Run(){
        ArrayList<CRoute> work=CSolution.CopyRouteList(CSolution.Route);
        normalizeOptions(work);
        int maxSteps=Math.max(10,CData.customerCount()*2);
        for(int step=0;step<maxSteps;step++){
            double total=energyViolation(work);
            if(total<=EPS){
                CSolution.Route=work; CSolution.UpdateInformation(); return true;
            }
            int bad=worstEnergyRoute(work);
            if(bad<0)break;
            ArrayList<CRoute> next=bestReducingRelocation(work,bad);
            if(next==null) next=bestSplit(work,bad);
            if(next==null)break;
            work=next; normalizeOptions(work);
        }
        if(energyViolation(work)<=EPS){CSolution.Route=work;CSolution.UpdateInformation();return true;}
        return false;
    }

    private static ArrayList<CRoute> bestReducingRelocation(ArrayList<CRoute> work,int bad){
        CRoute src=work.get(bad);
        double currentEV=energyViolation(work);
        ArrayList<CRoute> best=null; double bestEV=currentEV, bestTie=Double.POSITIVE_INFINITY;
        for(int pos=1;pos<src.path.size()-1;pos++){
            int c=src.path.get(pos);
            ArrayList<Integer> sp=new ArrayList<>(src.path); sp.remove(pos);
            CRoute newSrc=new CRoute();
            if(CSolution.customerCount(sp)>0){
                CEvaluationRoute.Run(sp,newSrc); if(!Double.isFinite(newSrc.cost))continue;
                selectRepairOption(newSrc);
            }else newSrc.isempty=true;

            for(int tr=0;tr<work.size();tr++){
                if(tr==bad)continue;
                CRoute tgt=work.get(tr);
                if(tgt.load+CData.nodes.get(c).demand>CData.Q+EPS)continue;
                for(int ins=1;ins<tgt.path.size();ins++){
                    ArrayList<Integer> tp=new ArrayList<>(tgt.path); tp.add(ins,c);
                    CRoute newTgt=new CRoute(); CEvaluationRoute.Run(tp,newTgt);
                    if(!Double.isFinite(newTgt.cost))continue;
                    selectRepairOption(newTgt);
                    ArrayList<CRoute> cand=CSolution.CopyRouteList(work);
                    cand.set(bad,newSrc); cand.set(tr,newTgt);
                    cand.removeIf(r->r==null||r.isempty||CSolution.customerCount(r.path)==0);
                    double ev=energyViolation(cand);
                    double tie=routeSurrogate(cand);
                    if(ev<bestEV-EPS || (Math.abs(ev-bestEV)<=EPS && ev<currentEV-EPS && tie<bestTie-EPS)){
                        bestEV=ev;bestTie=tie;best=cand;
                    }
                }
            }
        }
        return best;
    }

    private static ArrayList<CRoute> bestSplit(ArrayList<CRoute> work,int bad){
        CRoute src=work.get(bad);
        double currentEV=energyViolation(work);
        ArrayList<CRoute> best=null; double bestEV=currentEV,bestTie=Double.POSITIVE_INFINITY;
        for(int pos=1;pos<src.path.size()-1;pos++){
            int c=src.path.get(pos);
            ArrayList<Integer> sp=new ArrayList<>(src.path);sp.remove(pos);
            CRoute ns=new CRoute();
            if(CSolution.customerCount(sp)>0){CEvaluationRoute.Run(sp,ns);if(!Double.isFinite(ns.cost))continue;selectRepairOption(ns);}else ns.isempty=true;
            CRoute singleton=new CRoute();
            CEvaluationRoute.Run(new ArrayList<>(Arrays.asList(0,c,0)),singleton);
            if(!Double.isFinite(singleton.cost) || !selectPhysicalOption(singleton))continue;
            ArrayList<CRoute> cand=CSolution.CopyRouteList(work);
            cand.set(bad,ns); if(ns.isempty)cand.remove(bad); cand.add(singleton);
            double ev=energyViolation(cand),tie=routeSurrogate(cand);
            if(ev<bestEV-EPS || (Math.abs(ev-bestEV)<=EPS && ev<currentEV-EPS && tie<bestTie-EPS)){
                bestEV=ev;bestTie=tie;best=cand;
            }
        }
        return best;
    }

    private static void normalizeOptions(List<CRoute> routes){for(CRoute r:routes)selectRepairOption(r);}

    /** Prefer an energy-feasible option if the fixed sequence has one; otherwise minimum energy violation. */
    private static void selectRepairOption(CRoute r){
        if(r==null||r.isempty||r.options.isEmpty())return;
        int best=-1;double bestEV=Double.POSITIVE_INFINITY,bestScore=Double.POSITIVE_INFINITY;
        for(int i=0;i<r.options.size();i++){
            CRouteOption o=r.options.get(i);
            double ev=o.energyViolationPercent();
            double sc=o.distance+CData.penalty_init*o.lateness+CData.lambda*o.chargingTime;
            if(ev<bestEV-EPS || (Math.abs(ev-bestEV)<=EPS && sc<bestScore-EPS)){best=i;bestEV=ev;bestScore=sc;}
        }
        if(best>=0)r.selectOption(best);
    }

    private static boolean selectPhysicalOption(CRoute r){
        int best=-1;double s=Double.POSITIVE_INFINITY;
        for(int i=0;i<r.options.size();i++){
            CRouteOption o=r.options.get(i);if(!o.isEnergyFeasible())continue;
            double sc=o.distance+CData.penalty_init*o.lateness+CData.lambda*o.chargingTime;
            if(sc<s-EPS){s=sc;best=i;}
        }
        if(best<0)return false;r.selectOption(best);return true;
    }

    private static int worstEnergyRoute(List<CRoute> routes){
        int best=-1;double v=EPS;
        for(int i=0;i<routes.size();i++){
            CRouteOption o=routes.get(i).selectedOption();
            double x=o==null?Double.POSITIVE_INFINITY:o.energyViolationPercent();
            if(x>v){v=x;best=i;}
        }
        return best;
    }

    private static double energyViolation(List<CRoute> routes){
        double v=0;for(CRoute r:routes){CRouteOption o=r.selectedOption();if(o==null)return Double.POSITIVE_INFINITY;v+=o.energyViolationPercent();}return v;
    }

    private static double routeSurrogate(List<CRoute> routes){
        double s=0;for(CRoute r:routes){CRouteOption o=r.selectedOption();if(o==null)return Double.POSITIVE_INFINITY;s+=o.distance+CData.penalty_init*o.lateness;}return s;
    }
}
