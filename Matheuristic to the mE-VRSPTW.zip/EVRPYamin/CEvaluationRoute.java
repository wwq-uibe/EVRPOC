package EVRPYamin;

import java.util.*;

/** Fixed-route multigraph evaluation. Generates a nondominated RouteOption set. */
public final class CEvaluationRoute {
    private CEvaluationRoute() {}
    private static final double EPS = 1e-9;
    private static final int MAX_FORWARD_LABELS = 4000;
    private static final int MAX_ROUTE_OPTIONS = 500;
    public static double penalty_T;

    private static final class Label {
        final double distance, time, energy, lateness, latestPrefixDeparture;
        final Label previous;
        final int arcType;
        Label(double distance, double time, double energy, double lateness, double latestPrefixDeparture, Label previous, int arcType) {
            this.distance=distance; this.time=time; this.energy=energy; this.lateness=lateness;
            this.latestPrefixDeparture=latestPrefixDeparture; this.previous=previous; this.arcType=arcType;
        }
    }

    /** Backward-compatible evaluator. Returns the route search cost; hard infeasibility => +INF. */
    public static double Run(ArrayList<Integer> path, CRoute cr) {
        evaluate(path, cr);
        return cr.searchCost;
    }

    public static void evaluate(ArrayList<Integer> path, CRoute cr) {
        if (path == null || cr == null) throw new IllegalArgumentException("Null path or route");
        reset(cr, path);
        if (path.isEmpty() || isEmptyPath(path)) {
            cr.isempty = true;
            cr.last_depart_time = CData.nodes.get(0).early_time;
            return;
        }
        if (path.size() < 3 || path.get(0) != 0 || path.get(path.size()-1) != 0)
            throw new IllegalArgumentException("Nonempty path must be [0, customer..., 0]");

        double load = 0.0;
        for (int k=1;k<path.size()-1;k++) {
            int node = path.get(k);
            if (node <= 0 || node >= CData.nodes.size()) throw new IllegalArgumentException("Invalid customer " + node);
            load += CData.nodes.get(node).demand;
        }
        cr.load = load;
        if (load > CData.Q + EPS) { markHardInfeasible(cr); return; }

        List<Label> labels = new ArrayList<>();
        labels.add(new Label(0.0, CData.nodes.get(0).early_time, 0.0, 0.0,
                CData.nodes.get(0).due_time, null, -1));
        for (int k=1;k<path.size();k++) {
            int i=path.get(k-1), j=path.get(k);
            if (i==j) { markHardInfeasible(cr); return; }
            CNode dest = CData.nodes.get(j);
            List<Label> next = new ArrayList<>();
            for (Label lab : labels) {
                for (CDominance.Arc arc : CDominance.getArcs(i,j)) {
                    double e = lab.energy + arc.energy;
                    // V3.3: permit a narrow, penalized energy-infeasible corridor during
                    // routing search.  Physical incumbents/SP columns are still restricted
                    // to energy <= E elsewhere.
                    if (e > CData.E * CData.energyRelaxationFactor + EPS) continue;
                    double arrival = lab.time + arc.time;
                    double start = Math.max(arrival, dest.early_time);
                    double late = lab.lateness + Math.max(0.0, start - dest.due_time);
                    double leave = start + (j==0 ? 0.0 : dest.service_time);
                    int type = arc.type == CDominance.Type.EUCLIDEAN ? 0 : 1;
                    Label provisional = new Label(lab.distance + arc.distance, leave, e, late,
                            0.0, lab, type);
                    double latestPrefix = latestPrefixDeparture(path, k, provisional);
                    Label cand = new Label(provisional.distance, provisional.time, provisional.energy,
                            provisional.lateness, latestPrefix, lab, type);
                    addNondominated(next, cand);
                }
            }
            if (next.isEmpty()) { markHardInfeasible(cr); return; }
            if (next.size() > MAX_FORWARD_LABELS) next = trimLabels(next, MAX_FORWARD_LABELS);
            labels = next;
        }

        ArrayList<CRouteOption> options = new ArrayList<>();
        for (Label lab : labels) {
            CRouteOption o = toOption(path, lab);
            addOptionNondominated(options, o);
        }
        if (options.isEmpty()) { markHardInfeasible(cr); return; }
        if (options.size() > MAX_ROUTE_OPTIONS) options = trimOptions(options, MAX_ROUTE_OPTIONS);
        options.sort(Comparator.comparingDouble((CRouteOption o)->o.distance)
                .thenComparingDouble(o->o.chargingTime)
                .thenComparingDouble(o->-o.latestDeparture));
        cr.options = options;

        int best = chooseSearchOption(options);
        cr.selectOption(best);
        penalty_T = cr.penalty_t;
    }

    private static CRouteOption toOption(ArrayList<Integer> path, Label lab) {
        CRouteOption o = new CRouteOption();
        o.distance = lab.distance; o.energy = lab.energy; o.lateness = lab.lateness; o.routeEndTime = lab.time;
        ArrayList<Integer> rev = new ArrayList<>();
        for (Label p=lab; p.previous!=null; p=p.previous) rev.add(p.arcType);
        for (int i=rev.size()-1;i>=0;i--) o.arcTypes.add(rev.get(i));
        // A route above E is search-only and is never sent to the physical charging
        // scheduler.  Use the full-battery charging time merely as a finite surrogate.
        o.chargingTime = CDepotCharging.getDepotChargingTime(Math.min(o.energy, CData.E));
        o.latestDeparture = lab.lateness <= EPS ? lab.latestPrefixDeparture : CData.nodes.get(0).early_time;
        return o;
    }

    /** Latest depot departure allowed by the first k legs represented by a label. */
    private static double latestPrefixDeparture(ArrayList<Integer> path, int k, Label label) {
        int[] types = new int[k];
        Label p = label;
        for (int q=k-1; q>=0; q--) { types[q]=p.arcType; p=p.previous; }
        int lastNode = path.get(k);
        double latest = CData.nodes.get(lastNode).due_time;
        for (int q=k; q>=1; q--) {
            int i=path.get(q-1), j=path.get(q);
            CDominance.Arc a=findArc(i,j,types[q-1]);
            double service=i==0?0.0:CData.nodes.get(i).service_time;
            latest=Math.min(CData.nodes.get(i).due_time, latest-a.time-service);
        }
        return latest;
    }

    /** Latest feasible depot departure for this exact arc sequence. */
    private static double latestDeparture(ArrayList<Integer> path, ArrayList<Integer> arcTypes) {
        double latest = CData.nodes.get(0).due_time;
        for (int k=path.size()-1; k>=1; k--) {
            int i=path.get(k-1), j=path.get(k);
            CDominance.Arc a = findArc(i,j,arcTypes.get(k-1));
            double service = i==0 ? 0.0 : CData.nodes.get(i).service_time;
            double due = CData.nodes.get(i).due_time;
            latest = Math.min(due, latest - a.time - service);
        }
        return Math.max(CData.nodes.get(0).early_time, latest);
    }

    private static CDominance.Arc findArc(int i, int j, int type) {
        for (CDominance.Arc a : CDominance.getArcs(i,j)) {
            int t = a.type == CDominance.Type.EUCLIDEAN ? 0 : 1;
            if (t == type) return a;
        }
        throw new IllegalStateException("Arc type not found for " + i + "->" + j);
    }

    /** Select the best time-feasible option of an already evaluated route. */
    public static boolean selectBestTimeFeasible(CRoute cr) {
        int best=-1; double bs=Double.POSITIVE_INFINITY;
        for (int i=0;i<cr.options.size();i++) {
            CRouteOption o=cr.options.get(i);
            // Initial construction / physical route selection must remain truly feasible.
            if (!o.isPhysicalFeasible()) continue;
            double sc=o.distance + CData.lambda*o.chargingTime;
            if (sc<bs-EPS) { bs=sc; best=i; }
        }
        if (best<0) return false;
        cr.selectOption(best);
        return true;
    }

    private static int chooseSearchOption(List<CRouteOption> options) {
        int best=0;
        double bestScore=Double.POSITIVE_INFINITY;
        for (int i=0;i<options.size();i++) {
            CRouteOption o=options.get(i);
            double score=o.distance + CData.penalty_init*o.lateness
                    + CData.penaltyEnergy*o.energyViolationPercent()
                    + CData.lambda*o.chargingTime;
            if (score < bestScore - EPS || (Math.abs(score-bestScore)<=EPS && o.lateness < options.get(best).lateness-EPS)) {
                bestScore=score; best=i;
            }
        }
        return best;
    }

    private static void addNondominated(List<Label> labels, Label c) {
        for (Label o : labels) if (dominates(o,c)) return;
        labels.removeIf(o -> dominates(c,o));
        labels.add(c);
    }
    private static boolean dominates(Label a, Label b) {
        boolean nw = a.distance<=b.distance+EPS && a.time<=b.time+EPS && a.energy<=b.energy+EPS
                && a.lateness<=b.lateness+EPS && a.latestPrefixDeparture>=b.latestPrefixDeparture-EPS;
        boolean st = a.distance<b.distance-EPS || a.time<b.time-EPS || a.energy<b.energy-EPS
                || a.lateness<b.lateness-EPS || a.latestPrefixDeparture>b.latestPrefixDeparture+EPS;
        return nw && st;
    }

    private static void addOptionNondominated(List<CRouteOption> list, CRouteOption c) {
        for (CRouteOption o:list) if (optionDominates(o,c)) return;
        list.removeIf(o -> optionDominates(c,o));
        list.add(c);
    }
    private static boolean optionDominates(CRouteOption a, CRouteOption b) {
        // Preserve the exact V3.2 dominance relation among physical options.
        if(a.isEnergyFeasible() && b.isEnergyFeasible()){
            boolean nw = a.distance<=b.distance+EPS && a.chargingTime<=b.chargingTime+EPS
                    && a.lateness<=b.lateness+EPS && a.latestDeparture>=b.latestDeparture-EPS;
            boolean st = a.distance<b.distance-EPS || a.chargingTime<b.chargingTime-EPS
                    || a.lateness<b.lateness-EPS || a.latestDeparture>b.latestDeparture+EPS;
            return nw && st;
        }
        // For search-only relaxed options, energy itself is an additional resource.
        boolean nw = a.distance<=b.distance+EPS && a.energy<=b.energy+EPS
                && a.chargingTime<=b.chargingTime+EPS
                && a.lateness<=b.lateness+EPS && a.latestDeparture>=b.latestDeparture-EPS;
        boolean st = a.distance<b.distance-EPS || a.energy<b.energy-EPS
                || a.chargingTime<b.chargingTime-EPS
                || a.lateness<b.lateness-EPS || a.latestDeparture>b.latestDeparture+EPS;
        return nw && st;
    }

    private static List<Label> trimLabels(List<Label> in, int max) {
        // Preserve the complete V3.2 physical-label priority first; relaxed labels may
        // use only spare capacity and therefore can never crowd out an E-feasible label.
        ArrayList<Label> physical=new ArrayList<>(), relaxed=new ArrayList<>();
        for(Label l:in){ if(l.energy<=CData.E+EPS)physical.add(l); else relaxed.add(l); }
        Comparator<Label> physicalCmp=Comparator
                .comparingDouble((Label l)->l.distance + CData.penalty_init*l.lateness
                        + CData.lambda*CDepotCharging.getDepotChargingTime(l.energy))
                .thenComparingDouble(l->l.energy).thenComparingDouble(l->l.time)
                .thenComparingDouble(l->-l.latestPrefixDeparture);
        physical.sort(physicalCmp);
        if(physical.size()>=max)return new ArrayList<>(physical.subList(0,max));
        relaxed.sort(Comparator
                .comparingDouble((Label l)->l.distance + CData.penalty_init*l.lateness
                        + CData.penaltyEnergy*Math.max(0.0,(l.energy-CData.E)/CData.E*100.0)
                        + CData.lambda*CDepotCharging.getDepotChargingTime(CData.E))
                .thenComparingDouble(l->l.energy).thenComparingDouble(l->l.time)
                .thenComparingDouble(l->-l.latestPrefixDeparture));
        ArrayList<Label> out=new ArrayList<>(physical);
        int room=max-out.size();
        out.addAll(relaxed.subList(0,Math.min(room,relaxed.size())));
        return out;
    }
    private static ArrayList<CRouteOption> trimOptions(List<CRouteOption> in, int max) {
        // Same protection at route-option level: relaxed options augment, never replace,
        // the physical V3.2 option set.
        ArrayList<CRouteOption> physical=new ArrayList<>(), relaxed=new ArrayList<>();
        for(CRouteOption o:in){if(o.isEnergyFeasible())physical.add(o);else relaxed.add(o);}
        physical.sort(Comparator.comparingDouble((CRouteOption o)->o.distance + CData.penalty_init*o.lateness
                + CData.lambda*o.chargingTime));
        if(physical.size()>=max)return new ArrayList<>(physical.subList(0,max));
        relaxed.sort(Comparator.comparingDouble((CRouteOption o)->o.distance + CData.penalty_init*o.lateness
                + CData.penaltyEnergy*o.energyViolationPercent() + CData.lambda*o.chargingTime));
        ArrayList<CRouteOption> out=new ArrayList<>(physical);
        int room=max-out.size();
        out.addAll(relaxed.subList(0,Math.min(room,relaxed.size())));
        return out;
    }

    private static void reset(CRoute cr, ArrayList<Integer> path) {
        penalty_T=0; cr.path=new ArrayList<>(path); cr.firstArc=new ArrayList<>(); cr.options=new ArrayList<>();
        cr.selectedOptionIndex=-1; cr.total_energy=0; cr.cost=0; cr.searchCost=0; cr.travel_distance=0;
        cr.charging_time=0; cr.last_depart_time=0; cr.load=0; cr.penalty_t=0; cr.penalty_r=0; cr.penalty=0; cr.isempty=false;
    }
    private static boolean isEmptyPath(ArrayList<Integer> p) {
        return (p.size()==1 && p.get(0)==0) || (p.size()==2 && p.get(0)==0 && p.get(1)==0);
    }
    private static void markHardInfeasible(CRoute cr) {
        cr.cost=Double.POSITIVE_INFINITY; cr.searchCost=Double.POSITIVE_INFINITY; cr.total_energy=Double.POSITIVE_INFINITY;
        cr.travel_distance=Double.POSITIVE_INFINITY; cr.charging_time=Double.POSITIVE_INFINITY;
        cr.last_depart_time=CData.nodes.get(0).early_time; cr.firstArc.clear(); cr.options.clear(); cr.selectedOptionIndex=-1;
    }
}
