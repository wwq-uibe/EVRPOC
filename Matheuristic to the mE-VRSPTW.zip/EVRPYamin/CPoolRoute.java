package EVRPYamin;

import java.util.*;

/**
 * Bounded elite/diverse pool of physically feasible routes for V3.4 SP.
 *
 * Search-only energy-infeasible routes never enter the pool.  Unlike the old
 * append-until-full pool, V3.4 uses quality/age-aware replacement and protects
 * the current best depot-feasible incumbent from eviction.
 */
public final class CPoolRoute {
    private CPoolRoute() {}
    private static final double EPS=1e-9;
    private static int maxSize=1500;
    private static final int MAX_OPTIONS_PER_ROUTE=48;

    private static long tick=0L;
    private static final class Entry {
        final String key;
        CRoute route;
        long born,lastTouch;
        int spUses=0;
        boolean elite=false;
        Entry(String key,CRoute route,long t){this.key=key;this.route=route;born=lastTouch=t;}
    }

    private static final ArrayList<Entry> entries=new ArrayList<>();
    private static final HashMap<String,Entry> byPath=new HashMap<>();

    public static void Initialize(int size){
        maxSize=Math.max(100,size); entries.clear(); byPath.clear(); tick=0L;
    }

    public static boolean Add(CRoute r){
        if(r==null || r.isempty || CSolution.customerCount(r.path)==0)return false;
        CRoute compact=physicalCompactCopy(r);
        if(compact==null)return false;
        tick++;
        String key=key(r.path);
        Entry old=byPath.get(key);
        if(old!=null){
            old.route=merge(old.route,compact); old.lastTouch=tick; return false;
        }

        Entry neo=new Entry(key,compact,tick);
        if(entries.size()<maxSize){insert(neo);return true;}

        Entry worst=null; double worstScore=Double.NEGATIVE_INFINITY;
        for(Entry e:entries){
            if(e.elite)continue;
            double s=evictionScore(e);
            if(s>worstScore){worstScore=s;worst=e;}
        }
        if(worst==null)return false; // all entries currently protected

        // A full pool should still turn over: a clearly better new route replaces the
        // worst immediately; an old stale route can also be replaced by a competitive
        // newcomer so early search artifacts do not freeze the pool forever.
        double newScore=qualityScore(neo.route);
        double oldBase=qualityScore(worst.route);
        boolean stale=(tick-worst.lastTouch)>Math.max(200L,maxSize/4L);
        if(newScore<=oldBase+0.25 || stale){
            remove(worst); insert(neo); return true;
        }
        return false;
    }

    public static int AddAllPhysical(Collection<CRoute> rs){
        int n=0;if(rs==null)return 0;for(CRoute r:rs)if(Add(r))n++;return n;
    }

    /** Protect exactly the routes of the current best validated incumbent. */
    public static void SetEliteRoutes(Collection<CRoute> rs){
        for(Entry e:entries)e.elite=false;
        if(rs==null)return;
        AddAllPhysical(rs);
        for(CRoute r:rs){
            Entry e=byPath.get(key(r.path));
            if(e!=null){e.elite=true;e.lastTouch=++tick;}
        }
    }

    /** Reward routes that were selected in a charging-feasible SP incumbent. */
    public static void MarkSelected(Collection<CRoute> rs){
        if(rs==null)return;
        for(CRoute r:rs){
            Entry e=byPath.get(key(r.path));
            if(e!=null){e.spUses++;e.lastTouch=++tick;}
        }
    }

    public static int Size(){return entries.size();}
    public static CRoute Get(int i){return entries.get(i).route.copy();}
    public static ArrayList<CRoute> Snapshot(){
        ArrayList<CRoute> out=new ArrayList<>();
        for(Entry e:entries)out.add(e.route.copy());
        return out;
    }
    public static boolean ContainsPath(List<Integer> path){return byPath.containsKey(key(path));}

    private static void insert(Entry e){entries.add(e);byPath.put(e.key,e);}
    private static void remove(Entry e){entries.remove(e);byPath.remove(e.key);}
    private static String key(List<Integer> p){return p.toString();}

    /** Higher means a worse eviction candidate. */
    private static double evictionScore(Entry e){
        double age=Math.max(0L,tick-e.lastTouch);
        return qualityScore(e.route)+0.002*age-0.40*Math.min(10,e.spUses);
    }

    /** Lower is better.  Normalize by customer count to avoid favoring only long routes. */
    private static double qualityScore(CRoute r){
        int m=Math.max(1,CSolution.customerCount(r.path));
        double best=Double.POSITIVE_INFINITY;
        for(CRouteOption o:r.options){
            if(!o.isPhysicalFeasible())continue;
            double slack=Math.max(0.0,Math.min(o.latestDeparture,CData.lastChargingPeriod+1.0)
                    -CData.firstChargingPeriod-o.chargingTime);
            double s=o.distance/m + 0.020*o.chargingTime/m - 0.005*slack/m;
            if(s<best)best=s;
        }
        return best;
    }

    private static CRoute physicalCompactCopy(CRoute src){
        ArrayList<CRouteOption> feasible=new ArrayList<>();
        for(CRouteOption o:src.options)if(o.isPhysicalFeasible())feasible.add(o.copy());
        if(feasible.isEmpty())return null;
        feasible=compactOptions(feasible);
        CRoute r=src.copy();r.options=feasible;
        int best=0;
        for(int i=1;i<r.options.size();i++){
            CRouteOption a=r.options.get(i),b=r.options.get(best);
            if(a.distance<b.distance-EPS ||
                    (Math.abs(a.distance-b.distance)<=EPS && a.chargingTime<b.chargingTime-EPS))best=i;
        }
        r.selectOption(best);return r;
    }

    private static CRoute merge(CRoute a,CRoute b){
        CRoute out=a.copy();
        ArrayList<CRouteOption> all=new ArrayList<>();
        for(CRouteOption o:a.options)all.add(o.copy());
        for(CRouteOption o:b.options){
            boolean dup=false;for(CRouteOption q:all)if(sameOption(o,q)){dup=true;break;}
            if(!dup)all.add(o.copy());
        }
        out.options=compactOptions(all);
        int best=0;
        for(int i=1;i<out.options.size();i++){
            CRouteOption x=out.options.get(i),y=out.options.get(best);
            if(x.distance<y.distance-EPS ||
                    (Math.abs(x.distance-y.distance)<=EPS && x.chargingTime<y.chargingTime-EPS))best=i;
        }
        out.selectOption(best);return out;
    }

    private static boolean sameOption(CRouteOption a,CRouteOption b){
        return Math.abs(a.distance-b.distance)<=EPS && Math.abs(a.energy-b.energy)<=EPS
                && Math.abs(a.chargingTime-b.chargingTime)<=EPS
                && Math.abs(a.latestDeparture-b.latestDeparture)<=EPS
                && a.arcTypes.equals(b.arcTypes);
    }

    /** Remove depot-SP-dominated options before the diversity cap is applied. */
    private static ArrayList<CRouteOption> removeDominated(ArrayList<CRouteOption> in){
        boolean[] dead=new boolean[in.size()];
        for(int i=0;i<in.size();i++){
            if(dead[i])continue;
            CRouteOption a=in.get(i);
            for(int j=0;j<in.size();j++){
                if(i==j || dead[i])continue;
                CRouteOption b=in.get(j);
                boolean noWorse=b.distance<=a.distance+EPS &&
                        b.chargingTime<=a.chargingTime+EPS &&
                        b.latestDeparture>=a.latestDeparture-EPS;
                boolean strict=b.distance<a.distance-EPS ||
                        b.chargingTime<a.chargingTime-EPS ||
                        b.latestDeparture>a.latestDeparture+EPS;
                if(noWorse && strict)dead[i]=true;
            }
        }
        ArrayList<CRouteOption> out=new ArrayList<>();
        for(int i=0;i<in.size();i++)if(!dead[i])out.add(in.get(i));
        return out;
    }

    /** Keep a diverse nondominated physical option subset. */
    private static ArrayList<CRouteOption> compactOptions(ArrayList<CRouteOption> in){
        in=removeDominated(in);
        if(in.size()<=MAX_OPTIONS_PER_ROUTE){
            in.sort(Comparator.comparingDouble((CRouteOption o)->o.distance)
                    .thenComparingDouble(o->o.chargingTime).thenComparingDouble(o->-o.latestDeparture));
            return in;
        }
        LinkedHashSet<Integer> keep=new LinkedHashSet<>();
        addTop(in,keep,Comparator.comparingDouble((CRouteOption o)->o.distance)
                .thenComparingDouble(o->o.chargingTime),24);
        addTop(in,keep,Comparator.comparingDouble((CRouteOption o)->o.chargingTime)
                .thenComparingDouble(o->o.distance),12);
        addTop(in,keep,Comparator.comparingDouble((CRouteOption o)->-o.latestDeparture)
                .thenComparingDouble(o->o.distance),12);
        ArrayList<CRouteOption> out=new ArrayList<>();
        for(int i:keep){if(out.size()>=MAX_OPTIONS_PER_ROUTE)break;out.add(in.get(i).copy());}
        out.sort(Comparator.comparingDouble((CRouteOption o)->o.distance)
                .thenComparingDouble(o->o.chargingTime).thenComparingDouble(o->-o.latestDeparture));
        return out;
    }

    private static void addTop(ArrayList<CRouteOption> in,LinkedHashSet<Integer> keep,
                               Comparator<CRouteOption> cmp,int lim){
        ArrayList<Integer> idx=new ArrayList<>();for(int i=0;i<in.size();i++)idx.add(i);
        idx.sort((i,j)->cmp.compare(in.get(i),in.get(j)));
        for(int k=0;k<Math.min(lim,idx.size());k++)keep.add(idx.get(k));
    }
}
