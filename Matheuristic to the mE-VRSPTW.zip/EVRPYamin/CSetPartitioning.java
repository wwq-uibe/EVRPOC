package EVRPYamin;

import com.gurobi.gurobi.*;
import java.util.*;

/**
 * V3.4 restricted set-partitioning master with exact/proof-safe depot-charging
 * feasibility enforced by lazy constraints.
 *
 * Master variables are route-option binaries y_{r,o}.  The master selects a
 * customer partition and a physical multigraph option for every selected route.
 * Depot charging is NOT time-indexed in the master.  Instead, every integer MIP
 * incumbent is passed to the fixed-option charging scheduler.  If charging is
 * proven infeasible, a lazy no-good cut removes exactly that route-option vector.
 * If a valid charging schedule is constructed, the incumbent is accepted as a
 * genuine route+option+depot-feasible SP solution.
 *
 * A bounded exact DFS is used inside the callback.  A budget hit is UNKNOWN, not
 * infeasible: no cut is added and the SP is aborted, so correctness is preserved
 * and a difficult charging check cannot stall AILS for minutes.
 */
public final class CSetPartitioning {
    private CSetPartitioning() {}
    private static final double EPS=1e-8;

    // One fixed-option charging proof inside a MIPSOL callback is allowed this many
    // DFS states.  UNKNOWN causes a safe SP abort rather than an invalid lazy cut.
    private static final long LAZY_FIXED_DFS_LIMIT=200000L;

    public static final class Result {
        public boolean feasible=false;
        public boolean improved=false;
        public boolean chargingUnknown=false;
        public double distance=Double.POSITIVE_INFINITY;
        public int poolSize=0;
        public int routeOptionVars=0;
        /** Retained for log/backward compatibility.  V3.4 creates no start variables. */
        public int chargingStartVars=0;
        public int selectedRoutes=0;
        public int status=-1;
        public double mipGap=Double.NaN;
        public double buildSeconds=0.0;
        public double solveSeconds=0.0;
        public int chargingChecks=0;
        public int lazyCuts=0;
        public int unknownChecks=0;
        public long chargingDfsNodes=0L;
        public ArrayList<CRoute> routes=new ArrayList<>();
        public CChargingScheduler.ScheduleResult schedule=null;
    }

    private static final class OptionVar {
        final int id;
        final int routeIndex;
        final int optionIndex;
        final CRoute route;
        final CRouteOption option;
        final GRBVar y;
        OptionVar(int id,int routeIndex,int optionIndex,CRoute route,CRouteOption option,GRBVar y){
            this.id=id;this.routeIndex=routeIndex;this.optionIndex=optionIndex;
            this.route=route;this.option=option;this.y=y;
        }
    }

    /** Charging-feasibility separator called only for integer MIP incumbents. */
    private static final class ChargingLazyCallback extends GRBCallback {
        final ArrayList<OptionVar> optionVars;
        final GRBVar[] y;
        int checks=0,cuts=0,unknown=0;
        long dfsNodes=0L;
        boolean abortedOnUnknown=false;

        double bestDistance=Double.POSITIVE_INFINITY;
        ArrayList<CRoute> bestRoutes=null;
        CChargingScheduler.ScheduleResult bestSchedule=null;

        ChargingLazyCallback(ArrayList<OptionVar> optionVars){
            this.optionVars=optionVars;
            this.y=new GRBVar[optionVars.size()];
            for(int i=0;i<optionVars.size();i++)this.y[i]=optionVars.get(i).y;
        }

        @Override protected void callback(){
            if(where!=GRB.CB_MIPSOL) return;
            try{
                double[] val=getSolution(y);
                ArrayList<OptionVar> chosen=new ArrayList<>();
                for(int i=0;i<val.length;i++) if(val[i]>0.5) chosen.add(optionVars.get(i));
                if(chosen.isEmpty()) return;
                chosen.sort(Comparator.comparingInt((OptionVar v)->v.routeIndex)
                        .thenComparingInt(v->v.optionIndex));

                ArrayList<CRoute> routes=new ArrayList<>();
                int[] optionIdx=new int[chosen.size()];
                double d=0.0;
                for(int k=0;k<chosen.size();k++){
                    OptionVar v=chosen.get(k);
                    CRoute r=v.route.copy();
                    r.selectOption(v.optionIndex);
                    routes.add(r);
                    optionIdx[k]=v.optionIndex;
                    d+=v.option.distance;
                }

                checks++;
                // Greedy success is already a constructive feasibility certificate.
                CChargingScheduler.ScheduleResult sched=CChargingScheduler.greedySchedule(routes,optionIdx);
                if(!sched.feasible){
                    sched=CChargingScheduler.scheduleFixedOptionsWithBudget(
                            routes,optionIdx,LAZY_FIXED_DFS_LIMIT);
                    dfsNodes+=sched.dfsNodes;
                }

                if(sched.feasible){
                    if(d<bestDistance-EPS){
                        bestDistance=d;
                        bestRoutes=CSolution.CopyRouteList(routes);
                        bestSchedule=sched.copy();
                    }
                    return;
                }

                if(sched.budgetExceeded){
                    // UNKNOWN must never be cut as infeasible.  Abort this SP call and
                    // return the best already validated MIPSOL, if any.
                    unknown++;
                    abortedOnUnknown=true;
                    abort();
                    return;
                }

                // Fixed route-option vector is PROVEN depot-infeasible.  The cut keeps
                // the same customer routes available with alternative physical options.
                GRBLinExpr ng=new GRBLinExpr();
                for(OptionVar v:chosen) ng.addTerm(1.0,v.y);
                addLazy(ng,GRB.LESS_EQUAL,chosen.size()-1.0);
                cuts++;
            }catch(Exception ex){
                // A callback failure must not let an unchecked charging solution pass.
                abortedOnUnknown=true;
                unknown++;
                System.err.println("[SP] charging callback aborted: "+ex.getMessage());
                abort();
            }
        }
    }

    /** Backward-compatible entry point; maxRounds is obsolete in V3.4. */
    public static Result Run(double timeLimitSeconds,int maxRounds){
        return Run(timeLimitSeconds);
    }

    /** Solve one route-option restricted master with charging lazy constraints. */
    public static Result Run(double timeLimitSeconds){
        Result out=new Result();
        ArrayList<CRoute> pool=CPoolRoute.Snapshot();
        out.poolSize=pool.size();
        final int n=CData.customerCount();
        if(pool.isEmpty() || n<=0) return out;

        ArrayList<CRoute> usable=new ArrayList<>();
        for(CRoute r:pool)
            if(validSimpleRoute(r,n) && hasSchedulablePhysicalOption(r)) usable.add(r);
        pool=usable;
        out.poolSize=pool.size();
        if(pool.isEmpty() || !coversEveryCustomer(pool,n)) return out;

        GRBEnv env=null; GRBModel model=null;
        long build0=System.nanoTime();
        try{
            env=new GRBEnv(true);
            env.set(GRB.IntParam.OutputFlag,0);
            env.start();
            model=new GRBModel(env);
            model.set(GRB.IntParam.OutputFlag,0);
            model.set(GRB.IntParam.Threads,1);
            model.set(GRB.IntParam.MIPFocus,1);
            model.set(GRB.IntParam.LazyConstraints,1);
            model.set(GRB.DoubleParam.MIPGap,0.0);
            model.set(GRB.DoubleParam.TimeLimit,Math.max(0.05,timeLimitSeconds));

            ArrayList<OptionVar> optionVars=new ArrayList<>();
            @SuppressWarnings("unchecked")
            ArrayList<OptionVar>[] byRoute=new ArrayList[pool.size()];
            for(int j=0;j<pool.size();j++)byRoute[j]=new ArrayList<>();

            final double release=CData.firstChargingPeriod;
            final double horizonEnd=CData.lastChargingPeriod+1.0;

            for(int j=0;j<pool.size();j++){
                CRoute r=pool.get(j);
                for(int oi=0;oi<r.options.size();oi++){
                    CRouteOption o=r.options.get(oi);
                    if(!o.isPhysicalFeasible())continue;
                    double deadline=Math.min(o.latestDeparture,horizonEnd);
                    if(release+o.chargingTime>deadline+EPS)continue;
                    GRBVar y=model.addVar(0.0,1.0,o.distance,GRB.BINARY,"y_"+j+"_"+oi);
                    OptionVar ov=new OptionVar(optionVars.size(),j,oi,r,o,y);
                    optionVars.add(ov); byRoute[j].add(ov);
                }
            }
            out.routeOptionVars=optionVars.size();
            if(optionVars.isEmpty())return out;
            model.update();

            // At most one physical option of the same customer route.
            for(int j=0;j<pool.size();j++){
                if(byRoute[j].isEmpty())continue;
                GRBLinExpr e=new GRBLinExpr();
                for(OptionVar ov:byRoute[j])e.addTerm(1.0,ov.y);
                model.addConstr(e,GRB.LESS_EQUAL,1.0,"route_"+j);
            }

            // Every customer exactly once.
            for(int c=1;c<=n;c++){
                GRBLinExpr e=new GRBLinExpr();
                for(OptionVar ov:optionVars)if(containsCustomer(ov.route,c))e.addTerm(1.0,ov.y);
                model.addConstr(e,GRB.EQUAL,1.0,"cover_"+c);
            }

            // Cheap valid charging-capacity strengthening.  All depot jobs share the
            // same release time, so jobs whose deadlines are <= tau must fit in the
            // B chargers before tau.  Exact non-preemptive feasibility remains lazy.
            int B=Math.max(1,CData.B);
            for(double tau=release+10.0;tau<horizonEnd-EPS;tau+=10.0){
                GRBLinExpr e=new GRBLinExpr(); boolean any=false;
                for(OptionVar ov:optionVars){
                    double d=Math.min(ov.option.latestDeparture,horizonEnd);
                    if(d<=tau+EPS){e.addTerm(ov.option.chargingTime,ov.y);any=true;}
                }
                if(any)model.addConstr(e,GRB.LESS_EQUAL,B*(tau-release),"charge_prefix_"+(int)Math.round(tau));
            }
            GRBLinExpr totalCharge=new GRBLinExpr();
            for(OptionVar ov:optionVars)totalCharge.addTerm(ov.option.chargingTime,ov.y);
            model.addConstr(totalCharge,GRB.LESS_EQUAL,B*(horizonEnd-release),"charge_total");

            // Warm start from the best validated incumbent whenever its route-options
            // are still present in the bounded pool.  This gives the master a known
            // depot-feasible incumbent without creating any charging-start variables.
            applyWarmStart(optionVars);

            ChargingLazyCallback cb=new ChargingLazyCallback(optionVars);
            model.setCallback(cb);
            model.update();
            out.buildSeconds=(System.nanoTime()-build0)/1e9;

            long solve0=System.nanoTime();
            model.optimize();
            out.solveSeconds=(System.nanoTime()-solve0)/1e9;
            out.status=model.get(GRB.IntAttr.Status);
            out.chargingChecks=cb.checks;
            out.lazyCuts=cb.cuts;
            out.unknownChecks=cb.unknown;
            out.chargingDfsNodes=cb.dfsNodes;
            out.chargingUnknown=cb.abortedOnUnknown;
            try{out.mipGap=model.get(GRB.DoubleAttr.MIPGap);}catch(GRBException ignored){}

            // Only a callback-validated charging-feasible incumbent may leave SP.
            if(cb.bestRoutes==null || cb.bestSchedule==null || !cb.bestSchedule.feasible){
                System.out.printf(Locale.US,
                        "[SP] lazy pool=%d opts=%d checks=%d cuts=%d unknown=%d no-validated-solution status=%d build=%.2fs solve=%.2fs%n",
                        out.poolSize,out.routeOptionVars,out.chargingChecks,out.lazyCuts,out.unknownChecks,
                        out.status,out.buildSeconds,out.solveSeconds);
                return out;
            }

            out.feasible=true;
            out.distance=cb.bestDistance;
            out.routes=CSolution.CopyRouteList(cb.bestRoutes);
            out.schedule=cb.bestSchedule.copy();
            out.selectedRoutes=out.routes.size();

            CPoolRoute.MarkSelected(out.routes);
            out.improved=CSaveSolution.AcceptExternalFeasible(out.routes,out.schedule,"SP");

            System.out.printf(Locale.US,
                    "[SP] lazy pool=%d opts=%d checks=%d cuts=%d unknown=%d dfs=%d obj=%.1f routes=%d gap=%s improved=%s build=%.2fs solve=%.2fs%n",
                    out.poolSize,out.routeOptionVars,out.chargingChecks,out.lazyCuts,out.unknownChecks,
                    out.chargingDfsNodes,out.distance,out.selectedRoutes,
                    Double.isFinite(out.mipGap)?String.format(Locale.US,"%.3f%%",100.0*out.mipGap):"NA",
                    out.improved?"yes":"no",out.buildSeconds,out.solveSeconds);
        }catch(GRBException ex){
            System.err.println("[SP] Gurobi skipped: "+ex.getMessage());
        }finally{
            if(model!=null)try{model.dispose();}catch(Exception ignored){}
            if(env!=null)try{env.dispose();}catch(Exception ignored){}
        }
        return out;
    }

    private static void applyWarmStart(ArrayList<OptionVar> optionVars)throws GRBException{
        if(CSaveSolution.Best_Route_Depot_Feasible==null ||
                CSaveSolution.Best_Route_Depot_Feasible.isEmpty() ||
                CSaveSolution.Best_Depot_Schedule==null)return;

        HashMap<String,CRouteOption> wanted=new HashMap<>();
        for(CRoute r:CSaveSolution.Best_Route_Depot_Feasible){
            CRouteOption o=r.selectedOption();
            if(o!=null)wanted.put(pathKey(r.path),o);
        }
        for(OptionVar ov:optionVars){
            CRouteOption w=wanted.get(pathKey(ov.route.path));
            if(w!=null && sameOption(w,ov.option))ov.y.set(GRB.DoubleAttr.Start,1.0);
        }
    }

    private static boolean sameOption(CRouteOption a,CRouteOption b){
        return Math.abs(a.distance-b.distance)<=1e-7 &&
                Math.abs(a.energy-b.energy)<=1e-7 &&
                Math.abs(a.chargingTime-b.chargingTime)<=1e-7 &&
                Math.abs(a.latestDeparture-b.latestDeparture)<=1e-7 &&
                a.arcTypes.equals(b.arcTypes);
    }

    private static String pathKey(List<Integer> p){return p.toString();}

    private static boolean hasSchedulablePhysicalOption(CRoute r){
        double release=CData.firstChargingPeriod;
        double end=CData.lastChargingPeriod+1.0;
        for(CRouteOption o:r.options){
            if(!o.isPhysicalFeasible())continue;
            if(release+o.chargingTime<=Math.min(o.latestDeparture,end)+EPS)return true;
        }
        return false;
    }

    private static boolean containsCustomer(CRoute r,int c){
        for(int k=1;k<r.path.size()-1;k++)if(r.path.get(k)==c)return true;
        return false;
    }

    private static boolean validSimpleRoute(CRoute r,int n){
        if(r==null || r.path.size()<3 || r.path.get(0)!=0 || r.path.get(r.path.size()-1)!=0)return false;
        boolean[] seen=new boolean[n+1];
        for(int k=1;k<r.path.size()-1;k++){
            int c=r.path.get(k);
            if(c<1 || c>n || seen[c])return false;
            seen[c]=true;
        }
        return true;
    }

    private static boolean coversEveryCustomer(List<CRoute> pool,int n){
        boolean[] seen=new boolean[n+1];
        for(CRoute r:pool)for(int k=1;k<r.path.size()-1;k++)seen[r.path.get(k)]=true;
        for(int c=1;c<=n;c++)if(!seen[c])return false;
        return true;
    }
}
