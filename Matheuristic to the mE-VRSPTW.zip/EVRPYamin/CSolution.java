package EVRPYamin;

import java.util.*;

/** Current AILS solution. */
public final class CSolution {
    private CSolution() {}
    private static final double EPS=1e-8;

    public static ArrayList<CRoute> Route=new ArrayList<>();
    public static double cost=Double.POSITIVE_INFINITY;       // travel distance of selected options
    public static double searchCost=Double.POSITIVE_INFINITY;
    public static double timeViolation=0.0;
    /** Sum of route-energy excesses in percentage points of battery capacity. */
    public static double energyViolation=0.0;
    public static double depotViolation=0.0;
    public static boolean isroutefeasible=false;
    public static boolean isdepotfeasible=false;
    public static CChargingScheduler.ScheduleResult scheduleResult;

    public static void Init() {
        Route.clear(); cost=Double.POSITIVE_INFINITY; searchCost=Double.POSITIVE_INFINITY;
        timeViolation=energyViolation=depotViolation=0;
        isroutefeasible=isdepotfeasible=false; scheduleResult=null;
        resetNodePositions();
    }

    public static ArrayList<CRoute> CopyRouteList(List<CRoute> routes) {
        ArrayList<CRoute> out=new ArrayList<>(); for(CRoute r:routes) out.add(r.copy()); return out;
    }

    /** Re-evaluate fixed customer sequences under the CURRENT penalty values. */
    public static ArrayList<CRoute> ReevaluatedCopy(List<CRoute> routes) {
        ArrayList<CRoute> out=new ArrayList<>();
        for(CRoute old:routes){
            CRoute r=new CRoute();
            CEvaluationRoute.Run(new ArrayList<>(old.path),r);
            if(!r.isempty) out.add(r);
        }
        return out;
    }

    public static void SetRoutes(List<CRoute> routes) {
        Route=CopyRouteList(routes); UpdateInformation();
    }

    /**
     * Fast update.  V3.3 permits search routes with E < energy <= 1.10E.
     * Such a route is intentionally NOT passed to the physical depot scheduler;
     * it is scored by the adaptive energy penalty until search returns to E-feasibility.
     */
    public static void UpdateInformation() {
        Route.removeIf(r->r==null || r.isempty || customerCount(r.path)==0);
        updateNodePositions();
        cost=0; timeViolation=0; energyViolation=0; isroutefeasible=true;
        for (CRoute r:Route) {
            CRouteOption o=r.selectedOption();
            if (!Double.isFinite(r.cost) || o==null) {
                isroutefeasible=false; cost=Double.POSITIVE_INFINITY; break;
            }
            cost+=r.travel_distance;
            timeViolation+=Math.max(0,r.penalty_t);
            energyViolation+=o.energyViolationPercent();
            if (r.penalty_t>EPS || !o.isEnergyFeasible()) isroutefeasible=false;
        }
        if (!Double.isFinite(cost)) {
            energyViolation=depotViolation=Double.POSITIVE_INFINITY;
            isdepotfeasible=false; searchCost=Double.POSITIVE_INFINITY; scheduleResult=null; return;
        }

        // Search-only energy-infeasible states do not represent a physical charging
        // problem yet.  Keep them finite through pEnergy, but never mark depot-feasible.
        if (energyViolation>EPS) {
            // Search-only surrogate: preserve depot-congestion pressure, but never
            // interpret this schedule as physically feasible while any route exceeds E.
            CChargingScheduler.ScheduleResult surrogate=CChargingScheduler.searchSurrogateSchedule(Route);
            scheduleResult=null;
            depotViolation=surrogate.maxViolation;
            isdepotfeasible=false;
            searchCost=cost + CData.penalty_init*timeViolation + CData.penaltyEnergy*energyViolation
                    + CData.penaltyDepot*depotViolation;
            return;
        }

        scheduleResult=CChargingScheduler.evaluateCurrent(Route);
        depotViolation=scheduleResult.maxViolation;
        isdepotfeasible=isroutefeasible && scheduleResult.feasible;
        searchCost=cost + CData.penalty_init*timeViolation
                + CData.penaltyEnergy*energyViolation + CData.penaltyDepot*depotViolation;
    }

    /** More expensive global coordination of route options + fixed-option charging schedule. */
    public static CChargingScheduler.ScheduleResult OptimizeDepotOptions() {
        CChargingScheduler.ScheduleResult s=CChargingScheduler.optimizeOptions(Route,true);
        updateNodePositions();
        cost=0; timeViolation=0; energyViolation=0; isroutefeasible=true;
        for (CRoute r:Route) {
            CRouteOption o=r.selectedOption();
            if(o==null){isroutefeasible=false;continue;}
            cost+=r.travel_distance;
            timeViolation+=Math.max(0,r.penalty_t);
            energyViolation+=o.energyViolationPercent();
            if(r.penalty_t>EPS || !o.isEnergyFeasible()) isroutefeasible=false;
        }
        scheduleResult=s;
        depotViolation=s==null?Double.POSITIVE_INFINITY:s.maxViolation;
        isdepotfeasible=isroutefeasible && s!=null && s.feasible;
        searchCost=cost+CData.penalty_init*timeViolation+CData.penaltyEnergy*energyViolation
                +CData.penaltyDepot*depotViolation;
        return s;
    }

    /** Restore a charging schedule already validated when an incumbent was saved. */
    public static void RestoreDepotSchedule(CChargingScheduler.ScheduleResult saved) {
        if(saved==null || saved.optionIndex.length!=Route.size()) {
            UpdateInformation(); return;
        }
        for(int r=0;r<Route.size();r++) {
            int oi=saved.optionIndex[r];
            if(oi<0 || oi>=Route.get(r).options.size()) { UpdateInformation(); return; }
            Route.get(r).selectOption(oi);
        }
        updateNodePositions();
        cost=0; timeViolation=0; energyViolation=0; isroutefeasible=true;
        for(CRoute r:Route) {
            CRouteOption o=r.selectedOption();
            cost+=r.travel_distance;
            timeViolation+=Math.max(0,r.penalty_t);
            energyViolation+=o.energyViolationPercent();
            if(r.penalty_t>EPS || !o.isEnergyFeasible()) isroutefeasible=false;
        }
        scheduleResult=saved.copy();
        depotViolation=scheduleResult.maxViolation;
        isdepotfeasible=isroutefeasible && scheduleResult.feasible;
        searchCost=cost+CData.penalty_init*timeViolation+CData.penaltyEnergy*energyViolation
                +CData.penaltyDepot*depotViolation;
    }

    public static void ReevaluateAllRoutes() {
        ArrayList<CRoute> n=new ArrayList<>();
        for(CRoute old:Route) {
            CRoute r=new CRoute(); CEvaluationRoute.Run(new ArrayList<>(old.path),r);
            if (!r.isempty) n.add(r);
        }
        Route=n; UpdateInformation();
    }

    public static double ComputeSearchScore(List<CRoute> routes) {
        double d=0, late=0, eViol=0;
        ArrayList<CRoute> active=new ArrayList<>();
        for(CRoute r:routes) {
            if(r==null || r.isempty || customerCount(r.path)==0) continue;
            CRouteOption o=r.selectedOption();
            if(!Double.isFinite(r.cost) || o==null) return Double.POSITIVE_INFINITY;
            d+=r.travel_distance;
            late+=Math.max(0,r.penalty_t);
            eViol+=o.energyViolationPercent();
            active.add(r);
        }

        // Strategic-oscillation state: finite, penalized, but not sent to the
        // physical charging scheduler until all routes satisfy energy <= E.
        if(eViol>EPS) {
            CChargingScheduler.ScheduleResult surrogate=CChargingScheduler.searchSurrogateSchedule(active);
            return d+CData.penalty_init*late+CData.penaltyEnergy*eViol
                    +CData.penaltyDepot*surrogate.maxViolation;
        }

        CChargingScheduler.ScheduleResult sr=CChargingScheduler.evaluateCurrent(active);
        // For B>1 the EDF/list surrogate can report a false conflict even though a
        // different assignment to identical chargers is feasible. Exact-check only
        // promising, route-time-feasible cases to avoid slowing every move.
        if(!sr.feasible && CData.B>1 && active.size()<=10 && sr.maxViolation<=10.0 && late<=EPS){
            int[] idx=new int[active.size()];
            for(int i=0;i<idx.length;i++)idx[i]=active.get(i).selectedOptionIndex;
            CChargingScheduler.ScheduleResult exact=CChargingScheduler.scheduleFixedOptionsWithBudget(active,idx,15000L);
            if(exact.feasible || exact.maxViolation<sr.maxViolation-EPS) sr=exact;
        }
        return d+CData.penalty_init*late+CData.penaltyEnergy*eViol+CData.penaltyDepot*sr.maxViolation;
    }

    public static double ScoreAfterReplacement(int row1,CRoute r1,int row2,CRoute r2) {
        ArrayList<CRoute> temp=new ArrayList<>(Route);
        if(row1<0 || row1>=temp.size()) return Double.POSITIVE_INFINITY;
        temp.set(row1,r1);
        if(row2>=0 && row2<temp.size() && row2!=row1) temp.set(row2,r2);
        temp.removeIf(r->r==null || r.isempty || customerCount(r.path)==0);
        return ComputeSearchScore(temp);
    }

    public static double ScoreAfterAdd(int row1,CRoute r1,CRoute added) {
        ArrayList<CRoute> temp=new ArrayList<>(Route); temp.set(row1,r1); temp.add(added);
        return ComputeSearchScore(temp);
    }

    public static void Show() {
        System.out.println("================ Solution ================");
        for(int i=0;i<Route.size();i++) System.out.println((i+1)+"\t"+Route.get(i));
        System.out.printf(Locale.US,
                "Distance = %.1f, TW violation = %.1f, energy violation = %.2f%%, depot violation = %.1f, search = %.3f%n",
                cost,timeViolation,energyViolation,depotViolation,searchCost);
        System.out.println("route feasible="+isroutefeasible+", depot feasible="+isdepotfeasible);
        if(scheduleResult!=null && scheduleResult.feasible) {
            for(int r=0;r<Route.size();r++) System.out.printf(Locale.US,
                    "  charge route %d: charger=%d [%.0f, %.0f], deadline=%.1f%n",
                    r+1,scheduleResult.charger[r]+1,scheduleResult.start[r],scheduleResult.finish[r],Route.get(r).last_depart_time);
        }
        System.out.println("==========================================");
    }

    public static boolean ValidateCustomerCoverage() {
        int n=CData.customerCount(); int[] seen=new int[n+1];
        for(CRoute r:Route) for(int k=1;k<r.path.size()-1;k++) {
            int c=r.path.get(k); if(c<1 || c>n) return false; seen[c]++;
        }
        for(int c=1;c<=n;c++) if(seen[c]!=1) return false;
        return true;
    }

    private static void updateNodePositions() {
        resetNodePositions();
        for(int r=0;r<Route.size();r++) for(int p=1;p<Route.get(r).path.size()-1;p++) {
            int c=Route.get(r).path.get(p); CData.nodes.get(c).SetRow(r); CData.nodes.get(c).SetCol(p);
        }
    }
    private static void resetNodePositions() {
        if(CData.nodes==null) return; for(CNode n:CData.nodes){n.SetRow(-1);n.SetCol(-1);}
    }
    public static int customerCount(List<Integer> path) {
        int n=0; for(int x:path) if(x!=0)n++; return n;
    }
}
