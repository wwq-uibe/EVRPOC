package EVRPYamin;

import java.util.*;

/** Best-solution storage plus adaptive search penalties. */
public final class CSaveSolution {
    private CSaveSolution() {}
    private static final double EPS=1e-9;

    public static double best_route_depot_feasible_cost=Double.POSITIVE_INFINITY;
    public static ArrayList<CRoute> Best_Route_Depot_Feasible=new ArrayList<>();
    /** Validated charging schedule paired with Best_Route_Depot_Feasible. */
    public static CChargingScheduler.ScheduleResult Best_Depot_Schedule=null;

    public static double best_route_feasible_cost=Double.POSITIVE_INFINITY;
    public static ArrayList<CRoute> Best_Route_Feasible=new ArrayList<>();

    private static double penaltyUB=1000, penaltyLB=0.05, factor=1.5;
    private static double energyPenaltyUB=500.0, energyPenaltyLB=0.05, energyFactor=1.5;
    private static int updateEvery=20;
    private static int nTimeFea=0,nTimeInf=0,nDepotFea=0,nDepotInf=0,calls=0;
    private static int energyWindowCalls=0,energyWindowInf=0;

    private static final long DFS_NORMAL=8000L;
    private static final long DFS_PROMISING=30000L;
    private static final long DFS_INCUMBENT=200000L;

    private static final long JOINT_NORMAL_SEED=25000L;
    private static final long JOINT_NORMAL_REPAIR=12000L;
    private static final long JOINT_NORMAL_FINAL=50000L;
    private static final int  JOINT_NORMAL_PASSES=30;

    private static final long JOINT_INC_SEED=80000L;
    private static final long JOINT_INC_REPAIR=40000L;
    private static final long JOINT_INC_FINAL=400000L;
    private static final int  JOINT_INC_PASSES=40;

    private static final long V32_OPTION_STATE_LIMIT=10000L;
    private static final long V32_FIXED_DFS_LIMIT=5000L;
    private static final long V32_TOTAL_FIXED_DFS_LIMIT=150000L;
    private static final long V32_TIME_LIMIT_MS=750L;

    public static void Init(double ub,double lb,double fac,int update) {
        best_route_depot_feasible_cost=Double.POSITIVE_INFINITY;
        Best_Route_Depot_Feasible.clear(); Best_Depot_Schedule=null;
        best_route_feasible_cost=Double.POSITIVE_INFINITY; Best_Route_Feasible.clear();
        penaltyUB=ub;penaltyLB=lb;factor=fac;updateEvery=Math.max(2,update);
        nTimeFea=nTimeInf=nDepotFea=nDepotInf=calls=0; energyWindowCalls=energyWindowInf=0;
    }

    /** Returns true when adaptive penalty parameters were changed. */
    public static boolean Run() {
        calls++;

        // V3.3 route pool: only physically feasible route realizations are retained.
        CPoolRoute.AddAllPhysical(CSolution.Route);

        // Strategic oscillation penalties are based on the actually visited search state,
        // not on whether that sequence happens to contain a different feasible option.
        if(CSolution.timeViolation<=EPS){nTimeFea++;nTimeInf=0;}else{nTimeInf++;nTimeFea=0;}
        energyWindowCalls++;
        if(CSolution.energyViolation>EPS)energyWindowInf++;

        ArrayList<CRoute> candidate=CSolution.CopyRouteList(CSolution.Route);
        boolean routeFeasible=true;
        double routeDistance=0;
        for(CRoute r:candidate){
            int best=minDistanceFeasibleOption(r);
            if(best<0){routeFeasible=false;break;}
            r.selectOption(best);
            routeDistance+=r.travel_distance;
        }

        if(routeFeasible){
            if(routeDistance<best_route_feasible_cost-EPS){
                best_route_feasible_cost=routeDistance;
                Best_Route_Feasible=CSolution.CopyRouteList(candidate);
            }

            final boolean noIncumbent=Best_Route_Depot_Feasible.isEmpty();
            final boolean potentialIncumbent=noIncumbent || routeDistance<best_route_depot_feasible_cost-EPS;
            final boolean promising=potentialIncumbent
                    || routeDistance<best_route_depot_feasible_cost+25.0
                    || calls%25==0;

            int[] idx=currentIndices(candidate);
            CChargingScheduler.ScheduleResult sched=CChargingScheduler.greedySchedule(candidate,idx);
            boolean uncertain=false;

            if(!sched.feasible){
                long fixedBudget=potentialIncumbent?DFS_INCUMBENT:(promising?DFS_PROMISING:DFS_NORMAL);
                sched=CChargingScheduler.scheduleFixedOptionsWithBudget(candidate,idx,fixedBudget);
                uncertain |= sched.budgetExceeded;
            }

            if(!sched.feasible && promising){
                CChargingScheduler.ScheduleResult joint;
                if(potentialIncumbent){
                    joint=CChargingScheduler.optimizeOptionsWithBudget(candidate,true,
                            JOINT_INC_SEED,JOINT_INC_REPAIR,JOINT_INC_FINAL,JOINT_INC_PASSES);
                }else{
                    joint=CChargingScheduler.optimizeOptionsWithBudget(candidate,true,
                            JOINT_NORMAL_SEED,JOINT_NORMAL_REPAIR,JOINT_NORMAL_FINAL,JOINT_NORMAL_PASSES);
                }
                uncertain |= joint!=null && joint.budgetExceeded;
                if(joint!=null && (joint.feasible || betterSurrogate(joint,sched))) sched=joint;
            }

            boolean depotFeasible=sched!=null && sched.feasible;
            if(depotFeasible){
                double d=0;for(CRoute r:candidate)d+=r.travel_distance;
                nDepotFea++;nDepotInf=0;

                if(d<best_route_depot_feasible_cost-EPS && d>routeDistance+EPS){
                    CChargingScheduler.ScheduleResult refined=
                            CChargingScheduler.improveFeasibleOptionsBestFirst(candidate,sched,true,
                                    V32_OPTION_STATE_LIMIT,V32_FIXED_DFS_LIMIT,
                                    V32_TOTAL_FIXED_DFS_LIMIT,V32_TIME_LIMIT_MS);
                    if(refined!=null && refined.feasible && refined.distance<sched.distance-EPS){
                        sched=refined;
                        d=0;for(CRoute r:candidate)d+=r.travel_distance;
                    }
                }

                if(d<best_route_depot_feasible_cost-EPS){
                    acceptFeasible(candidate,sched,d,"AILS");
                }
            }else if(uncertain || (sched!=null && sched.budgetExceeded)){
                // UNKNOWN is not evidence of depot infeasibility.
                nDepotFea=0;nDepotInf=0;
            }else{
                nDepotInf++;nDepotFea=0;
            }
        }else{
            // Intentional energy-relaxed state: do not classify depot feasibility, but
            // also do not erase accumulated depot-infeasibility pressure from nearby
            // physical states.  The search surrogate still applies pDepot in CSolution.
        }

        boolean changed=false;
        if(nTimeInf>=updateEvery){
            CData.penalty_init=Math.min(penaltyUB,CData.penalty_init*factor);
            nTimeInf=0;changed=true;
        }
        if(nTimeFea>=updateEvery){
            CData.penalty_init=Math.max(penaltyLB,CData.penalty_init/factor);
            nTimeFea=0;changed=true;
        }
        if(energyWindowCalls>=updateEvery){
            double ratio=(double)energyWindowInf/Math.max(1,energyWindowCalls);
            if(ratio>0.25){
                CData.penaltyEnergy=Math.min(energyPenaltyUB,CData.penaltyEnergy*energyFactor);
                changed=true;
            }else if(ratio<0.05){
                CData.penaltyEnergy=Math.max(energyPenaltyLB,CData.penaltyEnergy/energyFactor);
                changed=true;
            }
            energyWindowCalls=energyWindowInf=0;
        }
        if(nDepotInf>=updateEvery){
            CData.lambda=Math.min(10.0,CData.lambda+0.05);
            CData.penaltyDepot=Math.min(100.0,CData.penaltyDepot*1.2);
            nDepotInf=0;changed=true;
        }
        if(nDepotFea>=updateEvery){
            CData.lambda=Math.max(0.0,CData.lambda-0.02);
            CData.penaltyDepot=Math.max(0.1,CData.penaltyDepot/1.1);
            nDepotFea=0;changed=true;
        }
        if(changed)CSolution.ReevaluateAllRoutes();
        return changed;
    }

    /** Accept a depot-feasible solution produced by the SP recombination layer. */
    public static boolean AcceptExternalFeasible(List<CRoute> routes,
                                                  CChargingScheduler.ScheduleResult sched,
                                                  String source){
        if(routes==null || sched==null || !sched.feasible || sched.optionIndex.length!=routes.size())return false;
        ArrayList<CRoute> copy=CSolution.CopyRouteList(routes);
        double d=0;
        for(int r=0;r<copy.size();r++){
            int oi=sched.optionIndex[r];
            if(oi<0 || oi>=copy.get(r).options.size())return false;
            copy.get(r).selectOption(oi);
            CRouteOption o=copy.get(r).selectedOption();
            if(o==null || !o.isPhysicalFeasible())return false;
            d+=o.distance;
        }
        CPoolRoute.AddAllPhysical(copy);
        if(d<best_route_depot_feasible_cost-EPS){
            acceptFeasible(copy,sched,d,source==null?"external":source);
            return true;
        }
        return false;
    }

    private static void acceptFeasible(List<CRoute> routes,CChargingScheduler.ScheduleResult sched,
                                       double d,String source){
        best_route_depot_feasible_cost=d;
        Best_Route_Depot_Feasible=CSolution.CopyRouteList(routes);
        Best_Depot_Schedule=sched.copy();
        CPoolRoute.AddAllPhysical(routes);
        CPoolRoute.SetEliteRoutes(Best_Route_Depot_Feasible);
        if("SP".equals(source))
            System.out.printf(Locale.US,"[SP] new incumbent %.1f routes=%d pool=%d%n",d,routes.size(),CPoolRoute.Size());
    }

    private static boolean betterSurrogate(CChargingScheduler.ScheduleResult a,
                                           CChargingScheduler.ScheduleResult b){
        if(a==null)return false;
        if(b==null)return true;
        if(a.maxViolation<b.maxViolation-EPS)return true;
        if(a.maxViolation>b.maxViolation+EPS)return false;
        if(a.totalViolation<b.totalViolation-EPS)return true;
        if(a.totalViolation>b.totalViolation+EPS)return false;
        return a.distance<b.distance-EPS;
    }

    private static int minDistanceFeasibleOption(CRoute r){
        int best=-1;double d=Double.POSITIVE_INFINITY;
        for(int i=0;i<r.options.size();i++){
            CRouteOption o=r.options.get(i);
            if(o.isPhysicalFeasible()&&o.distance<d){d=o.distance;best=i;}
        }
        return best;
    }

    private static int[] currentIndices(List<CRoute> r){
        int[]x=new int[r.size()];
        for(int i=0;i<x.length;i++)x[i]=r.get(i).selectedOptionIndex;
        return x;
    }

    public static void Show() {
        System.out.println("Best route-feasible distance: "+best_route_feasible_cost);
        System.out.println("Best route+depot-feasible distance: "+best_route_depot_feasible_cost);
        if(!Best_Route_Depot_Feasible.isEmpty()){
            ArrayList<CRoute> old=CSolution.CopyRouteList(CSolution.Route);
            CSolution.Route=CSolution.CopyRouteList(Best_Route_Depot_Feasible);
            CSolution.RestoreDepotSchedule(Best_Depot_Schedule);
            CSolution.Show();
            CSolution.Route=old;
            CSolution.UpdateInformation();
        }
    }
}
