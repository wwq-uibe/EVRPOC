package EVRPYamin;

/** Yamín depot charging function. One charging period = one minute. */
public final class CDepotCharging {
    private static final double EPS = 1e-9;
    private CDepotCharging() {}

    /** Number of whole one-minute charging periods needed to charge from zero to energy. */
    public static int getDepotChargingPeriods(double energy) {
        if (!Double.isFinite(energy) || energy < -EPS || energy > CData.E + EPS)
            return Integer.MAX_VALUE;
        if (energy <= EPS) return 0;
        if (CData.chargingBreakpoints == null || CData.chargingBreakpoints.length == 0)
            throw new IllegalStateException("Charging function not loaded");
        double target = Math.min(energy, CData.E);
        double previous = 0.0;
        double periods = 0.0;
        for (int p=0; p<CData.chargingBreakpoints.length && target > previous + EPS; p++) {
            double upper = Math.min(target, CData.chargingBreakpoints[p]);
            if (upper > previous) periods += (upper - previous) / CData.chargingRates[p];
            previous = CData.chargingBreakpoints[p];
        }
        return (int)Math.ceil(periods - 1e-9);
    }

    /** Charging time in minutes, rounded up to complete one-minute charging periods. */
    public static double getDepotChargingTime(double energy) {
        int p = getDepotChargingPeriods(energy);
        return p == Integer.MAX_VALUE ? Double.POSITIVE_INFINITY : (double)p;
    }
}
