package EVRPYamin;

import java.util.*;

/** Customer candidate-list generator, adapted from the EVRPOC AILS code. */
public final class CLingyu {
    private CLingyu() {}
    private static final ArrayList<ArrayList<Integer>> cusPairs=new ArrayList<>();
    public static Random ran=new Random();

    public static void Init(double neighborRatio) {
        cusPairs.clear();
        int n=CData.customerCount();
        int k=Math.max(2,(int)Math.ceil((n-1)*Math.min(1.0,Math.max(0.02,neighborRatio))));
        for(int i=1;i<=n;i++) {
            final int ii=i;
            ArrayList<Integer> others=new ArrayList<>();
            for(int j=1;j<=n;j++) if(j!=i) others.add(j);
            others.sort(Comparator.comparingDouble(j->relatedness(ii,j)));
            for(int z=0;z<Math.min(k,others.size());z++) {
                ArrayList<Integer> p=new ArrayList<>(); p.add(i); p.add(others.get(z)); cusPairs.add(p);
            }
        }
    }

    public static ArrayList<ArrayList<Integer>> GetCandiCUSList(double sampleRatio) {
        ArrayList<ArrayList<Integer>> x=new ArrayList<>();
        if(cusPairs.isEmpty()) return x;
        int m=Math.max(1,(int)Math.ceil(cusPairs.size()*Math.min(1.0,Math.max(0.02,sampleRatio))));
        ArrayList<Integer> ids=new ArrayList<>(); for(int i=0;i<cusPairs.size();i++) ids.add(i);
        Collections.shuffle(ids,ran);
        for(int z=0;z<Math.min(m,ids.size());z++) x.add(new ArrayList<>(cusPairs.get(ids.get(z))));
        return x;
    }

    public static int[] GetBreakPoint(double ratio) {
        int n=CData.customerCount(); int m=Math.max(1,(int)Math.ceil(n*Math.max(0.02,Math.min(1.0,ratio))));
        int[] a=new int[m]; for(int i=0;i<m;i++) a[i]=1+ran.nextInt(n); return a;
    }

    private static double relatedness(int i,int j) {
        double d=Math.min(CData.euclideanDistance[i][j],CData.manhattanDistance[i][j]);
        CNode a=CData.nodes.get(i), b=CData.nodes.get(j);
        double tw=Math.max(0,b.early_time-a.due_time-a.service_time-d)
                +Math.max(0,a.early_time+a.service_time+d-b.due_time);
        return d+0.2*tw;
    }
}
